<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <title>Registro</title>
</head>
<body>

<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a id="inbox" href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>


<main>
<div class="row">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card glass-effect" style="width: 28rem;">
      <div class="card-body">
      <h5 class="card-title">Busqueda cliente</h5>
      <?php if(isset($_GET['alert_message'])): ?>
      <div class="alert alert-<?php echo $_GET['alert_type']; ?>" role="alert">
          <?php echo $_GET['alert_message']; ?>
      </div>
      <?php endif; ?>
      <form method="post" action="registro_cliente2.php" id="registroForm" onsubmit="return validarFormulario()">
          <label class="" for="nombre">CURP:</label>
          <input class="form-control inputs" type="text" name="Curp" id="Curp" required>
  
          <label for="nombre">Nombre Completo:</label>
          <input class="form-control inputs" type="text" name="NombreCom" id="NombreCom">
  
          <label for="nombre">Numero de telefono:</label>
          <input class="form-control inputs" type="text" name="Telefono" id="Telefono">
  
          <label for="nombre">Direccion:</label>
          <input class="form-control inputs" type="text" name="Direccion" id="Direccion">

          <label for="nombre">Numero de tarjeta:</label>
          <input class="form-control inputs" type="text" name="Tarjeta" id="inputTarjeta" >
  
          <label for="nombre">Vigencia:</label>
          <input class="form-control inputs" type="text" name="Vigencia" id="Vigencia">
  
          <label for="nombre">Tipo de pago:</label>
          <input class="form-control inputs" type="text" name="Pago" id="Pago">
  
          <label for="nombre">Monto total:</label>
          <input class="form-control inputs" type="number" id="currencyInput" min="0.01" step="0.01" value="1.00" /><br>
  
          <input type="hidden" name="imagen" id="imagen">
          <button type="button" class="btn btn-primary" id="buscarPorTarjeta">Buscar Cliente</button>
      </form>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card glass-effect" style="width: 28rem;">
      <div class="card-body">
      <h5 class="card-title">Escaneo de tarjeta RFID</h5>
      <div class="alert alert-info" role="alert">
          <label for="inputManualTarjeta">Ingrese el número de tarjeta:</label>
          <input type="text" class="form-control" id="inputManualTarjeta" placeholder="Escriba el número aquí">
      </div>
      </div>
    </div>
  </div>
</div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Función para manejar la búsqueda de cliente por tarjeta RFID
        function buscarClientePorTarjeta(numeroTarjeta) {
            // Realizar una solicitud AJAX para buscar al cliente por el número de tarjeta
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'buscar_cliente.php?numero_tarjeta=' + numeroTarjeta, true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        var datosCliente = JSON.parse(xhr.responseText);
                        document.getElementById('Curp').value = datosCliente.CURP || '';
                        document.getElementById('NombreCom').value = datosCliente.NOMBRECOM || '';
                        document.getElementById('Telefono').value = datosCliente.TELEFONO || '';
                        document.getElementById('Direccion').value = datosCliente.DIRECCION || '';
                        document.getElementById('Vigencia').value = datosCliente.VIGENCIA || '';
                        document.getElementById('inputTarjeta').value = datosCliente.NUMEROTARJETA || '';
                    } catch (error) {
                        console.error('Error al analizar JSON:', error);
                        alert('Hubo un error al procesar la respuesta del servidor.');
                    }
                } else {
                    console.log('Error al buscar el cliente');
                    alert('Error al buscar el cliente. Por favor, intente nuevamente.');
                }
            };

            xhr.onerror = function() {
                console.log('Error en la solicitud AJAX');
                alert('Error en la solicitud AJAX. Por favor, intente nuevamente.');
            };

            xhr.send();
        }

        // Evento para escuchar cuando se busca por tarjeta manualmente
        document.getElementById('buscarPorTarjeta').addEventListener('click', function() {
            var numeroTarjeta = document.getElementById('inputManualTarjeta').value.trim();

            if (numeroTarjeta !== '') {
                buscarClientePorTarjeta(numeroTarjeta);
            } else {
                alert('Por favor ingrese un número de tarjeta válido.');
            }
        });
    });
</script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
