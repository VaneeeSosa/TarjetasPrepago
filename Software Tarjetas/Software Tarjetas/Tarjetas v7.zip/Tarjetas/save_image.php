<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $image = $data['image'];
    $decodedImage = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $image));

    $nombreCom = isset($_POST['NombreCom']) ? $_POST['NombreCom'] : 'default';
    $directory = 'uploads/' . $nombreCom;
    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }

    $filePath = $directory . '/foto.png';
    file_put_contents($filePath, $decodedImage);

    $response = ['success' => true, 'path' => $filePath];
    echo json_encode($response);
}
?>
