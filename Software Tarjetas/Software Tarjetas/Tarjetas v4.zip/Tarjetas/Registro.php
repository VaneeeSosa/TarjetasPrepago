<?php
// Sesiones
session_start();

// aquí se valida si existe un cerrar sesion, si existe se termina la sesion
if (isset($_GET['cerrar_sesion'])) {
    session_unset();
    session_destroy();
}




?>
<!DOCTYPE html>
<html>
<head>
    <title>Registro de Usuario</title>
    <script src="JS\ValidacionRegistro.js"></script>
</head>
<body>

<h2>Registro de Nuevo Usuario</h2>

<form method="post" action="registro_usuario.php" onsubmit="return validarFormulario()">
    <label for="nombre">Curp:</label><br>
    <input type="text" id="Curp" name="Curp" required><br><br>

    <label for="nombre">Nombre Completo:</label><br>
    <input type="text" id="NomCompleto" name="NomCompleto" required><br><br>

    <label for="nombre">Nombre de Usuario:</label><br>
    <input type="text" id="NomUsuario" name="NomUsuario" required><br><br>

    <label for="Contrasena">Contraseña:</label><br>
    <input type="password" id="Contrasena" name="Contrasena" required><br><br>

    <label for="confirmar_contrasena">Confirmar Contraseña:</label><br>
    <input type="password" id="Confirmar_Contrasena" name="Confirmar_Contrasena" required><br><br>

    <label for="rol">Rol:</label><br>
    <select id="Rol" name="Rol" required>
        <option value= "1">Empleado</option>
        <option value= "2">Administrador</option>
    </select><br><br>

    <label for="rol">Estatus:</label><br>
    <select id="Estatus" name="Estatus" required>
        <option value= "1">Activo</option>
        <option value= "2">Inactivo</option>
    </select><br><br>

    <input type="submit" value="Registrar">
</form>

</body>
</html>
