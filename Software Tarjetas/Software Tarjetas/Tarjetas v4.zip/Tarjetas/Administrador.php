<?php
session_start();
// Función para redirigir según el rol del usuario
function redirigirSegunRol() {
    if (isset($_SESSION['rol'])) {
        if ($_SESSION['rol'] == 2) {
            // Si el rol es 1, el usuario es un Administrador, no realiza ninguna accion

        } elseif ($_SESSION['rol'] == 1) {
            // Si el rol es 1, el usuario es un Empleado, redirigir a la página de Empleado
            header('Location: Empleado.php');
            exit();
        }
    } else {
        // Si no se ha establecido el rol en la sesión, redirigir a la página de inicio de sesión
        header('Location: Login.php');
        exit();
    }
}

// Función para cerrar sesión
function cerrarSesion() {
    // Destruir todas las variables de sesión
    session_destroy();
    // Redirigir al usuario a la página de inicio de sesión
    header('Location: login.php');
    exit();
}

// Verificar si se hizo clic en el botón de cerrar sesión
if (isset($_POST['cerrar_sesion'])) {
    cerrarSesion();
}

redirigirSegunRol();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleado</title>
</head>
<body>
    <h1>ADMINISTRADOR</h1>

    <!-- Botón para cerrar sesión -->
    <form action="" method="post">
        <button type="submit" name="cerrar_sesion">Cerrar sesión</button>
    </form>
</body>
</html>
