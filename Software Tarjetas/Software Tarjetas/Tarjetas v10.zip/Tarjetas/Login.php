<?php
// Sesiones
session_start();

// Incluir el archivo de conexión
require_once('Conexion.php');

// Crear una instancia de la clase de conexión
$conexion = new Conexion();
$getConnection = $conexion->Conectar();

// Comprobar si se ha solicitado cerrar sesión
if (isset($_GET['cerrar_sesion'])) {
    session_unset();
    session_destroy();
}

// Redirigir al usuario según su rol si ya está autenticado
if (isset($_SESSION['rol'])) {
    switch ($_SESSION['rol']) {
        case 1:
            header('location: Empleado.php');
            exit();
        case 2:
            header('location: Administrador.php');
            exit();
    }
}

// Autenticar al usuario si se han enviado datos de inicio de sesión
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Preparar la consulta SQL
    $sql = "SELECT * FROM Usuarios WHERE Usuario = :username AND Contrasena = :password";
    $stmt = $getConnection->prepare($sql);
    
    // Asignar valores a los parámetros y ejecutar la consulta
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();

    // Obtener el resultado
    $resultados = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($resultados) {
       // Obtener el rol del usuario y establecerlo en la sesión
$rol = $resultados['IDROL'];
$estatus = $resultados['IDESTATUS'];
$_SESSION['rol'] = $rol;

// Verificar el estado del usuario
if ($estatus === '1') {
    // Redirigir al usuario según su rol
    switch ($_SESSION['rol']) {
        case 1:
            header('location: empleado.php');
            exit();
        case 2:
            header('location: Administrador.php');
            exit();
        default:
            header('location: Login.php');
            exit();
    }
} else {
    // Usuario inactivo
    echo "Usuario inactivo";
}

    } else {
        $mostrarError = true;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/login.css">

    <title>Login</title>
</head>
<body>

<!-- ELIPSES -->
<div class="container text-center">
        <img src="./img/Ellipse 2.png" class="ellipse" style="left: 0; top: 0; width: 585px; height: 556px;" alt="Elipse 1">
        <img src="./img/Ellipse 3.png" class="ellipse" style="right: 0; bottom: 0; width: 585px; height: 556px;" alt="Elipse 2">
        <img src="./img/Ellipse 4.png" class="ellipse" style="left: 596px; top: 46px; width: 106px; height: 102px;" alt="Elipse 3">
        <img src="./img/Ellipse 6.png" class="ellipse" style="left: 56px; bottom: 0; width: 65px; height: 66px;" alt="Elipse 4">
        <img src="./img/Ellipse 5.png" class="ellipse" style="right: 0; top: 0; width: 153px; height: 150px;" alt="Elipse 5">
        <img src="./img/Ellipse 7.png" class="ellipse" style="right: 0; bottom: 0; width: 45px; height: 45px;" alt="Elipse 6">
</div>

<div class="container-fluid">
    <div class="row justify-content-center mt-5">
    <div class="card glass-effect border-none" style="width: 38rem;">
        <div class="card-body">
            <h5 class="card-title text-center titulos">Hola</h5>
        <form action="#" method="POST">
            <p class="card-text subtitles">Nombre de usuario: </p>
            <input class="form-control inputs" type="text" name="username"><br/>
            <p class="card-text subtitles">Contraseña:</p>
            <input class="form-control inputs" type="password" name="password"><br/>
            <div class="d-flex justify-content-end">
            <input class="btn btn-primary btnEnviar" type="submit" value="Iniciar Sesion">
            </div>
        </form>
        <!-- Alerta de error -->
        <div class="alert alert-danger alert-custom mt-3" role="alert" style="display: <?php echo isset($mostrarError) && $mostrarError ? 'block' : 'none'; ?>">
                    El usuario o la contraseña son incorrectos.
                </div>
        </div>
    </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>
