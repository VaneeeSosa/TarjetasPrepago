<?php
// Realizar el corte de caja
include 'corte_caja.php';

// Función para redirigir según el rol del usuario
function redirigirSegunRol() {
    // Verifica si hay una sesión activa y el rol del usuario
    if (isset($_SESSION['rol'])) {
        $rol = $_SESSION['rol'];
        
        // Si el usuario es un empleado (rol 1)
        if ($rol == 1) {
            $pagina_actual = basename($_SERVER['PHP_SELF']);
            // Permite acceso solo a 'registro_cliente.php' y 'consulta_clientes.php' para empleados
            if ($pagina_actual != 'registroCliente.php' && $pagina_actual != 'ActualizarUsuario.php' && $pagina_actual != 'BusquedaCliente') {
                header('Location: Error.php'); 
                exit();
            }
        }
    } else {
        // Si no se ha establecido el rol en la sesión, redirigir a la página de inicio de sesión
        header('Location: login.php');
        exit();
    }
}

// Función para cerrar sesión
function cerrarSesion() {
    // Destruir todas las variables de sesión
    session_destroy();

    // Redirigir al usuario inicio de sesión
    header('Location: login.php');
    exit();
}

// Verificacion botón de cerrar sesión
if (isset($_POST['cerrar_sesion'])) {
    cerrarSesion();
}

// Llamar a la función de redirección
redirigirSegunRol();


    // Este sirve para llamar la conexion
    require_once('Conexion.php');

    $con = new Conexion();
    $getConnection = $con->Conectar();

    // Definir variables para filtros
    $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : '';
    $curp = isset($_POST['curp']) ? $_POST['curp'] : '';
    $rol = isset($_POST['rol']) ? $_POST['rol'] : '';
    $estado = isset($_POST['estado']) ? $_POST['estado'] : '';

    // Construir la consulta base
    $sql = "SELECT u.Curp, u.Nombre, u.Contrasena, r.rol as Rol, e.Estatus as Estado, u.Usuario 
    FROM Usuarios u 
    JOIN Rol r ON u.IDROL = r.IDROL
    JOIN Estatus e ON u.IDESTATUS = e.IDESTATUS";


    // Agregar filtros según los campos completados en el formulario
    $params = [];
    $conditions = [];

    if (!empty($nombre)) {
        $conditions[] = "u.Nombre LIKE ?";
        $params[] = "%$nombre%";
    }

    if (!empty($curp)) {
        $conditions[] = "u.Curp = ?";
        $params[] = $curp;
    }

    if (!empty($rol)) {
        $conditions[] = "u.IDROL = ?";
        $params[] = $rol;
    }

    if (!empty($estado)) {
        $conditions[] = "u.IDESTATUS = ?";
        $params[] = $estado;
    }

    // Agregar condiciones a la consulta si hay filtros aplicados
    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }

    // Preparar y ejecutar la consulta
    $stmt = $getConnection->prepare($sql);
    $stmt->execute($params);

    // Almacenar resultados en un array asociativo
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/tablas.css">
</head>
<body>
<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a id="inbox" href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="cerrar_sesion.php">
                    <i class='bx bx-exit'></i>
                       <span>Cerrar sesión</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
<main class="d-flex justify-content-start">
    <div class="">
        <h1 class="titulos">Listado de Usuarios</h1>
        <form method="POST" class="mb-3">
            <div class="form-row glass-effect">
                <div class="col-md-3 mb-2">
                    <input type="text" name="nombre" class="form-control inputs subtitles" placeholder="Buscar por nombre" value="<?php echo htmlspecialchars($nombre); ?>">
                </div>
                <div class="col-md-3 mb-2">
                    <input type="text" name="curp" class="form-control inputs subtitles" placeholder="Buscar por CURP" value="<?php echo htmlspecialchars($curp); ?>">
                </div>
                <div class="col-md-3 mb-2">
                    <select name="rol" class="form-control subtitles inputs">
                        <option class="subtitles inputs" value="">Todos los roles</option>
                        <option class="subtitles" value="2" <?php if ($rol == '2') echo 'selected'; ?>>Admin</option>
                        <option class="subtitles" value="1" <?php if ($rol == '1') echo 'selected'; ?>>Empleado</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <select name="estado" class="form-control subtitles inputs">
                        <option class="subtitles inputs" value="">Estatus</option>
                        <option class="subtitles" value="1" <?php if ($estado == '1') echo 'selected'; ?>>Activo</option>
                        <option class="subtitles" value="2" <?php if ($estado == '2') echo 'selected'; ?>>Inactivo</option>
                    </select>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" name="Filtros" class="btn btn-primary btnEnviar">Buscar</button>
                </div>
            </div>
        </form>
        <table class="table">
            <thead>
                <tr>
                    <th>Curp</th>
                    <th>Nombre</th>
                    <th>Contraseña</th>
                    <th>Rol</th>
                    <th>Usuario</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($usuarios as $usuario): ?>
                    <tr>
                        <td><?php echo $usuario['CURP']; ?></td>
                        <td><?php echo $usuario['NOMBRE']; ?></td>
                        <td><?php echo $usuario['CONTRASENA']; ?></td>
                        <td><?php echo $usuario['ROL']; ?></td>
                        <td><?php echo $usuario['USUARIO']; ?></td>
                        <td><?php echo $usuario['ESTADO']; ?></td>
                        <td>
                            <!-- Botón Editar -->
                            <a href="ActualizarUsuario.php?CURP=<?php echo $usuario['CURP'] ?>" class="btn btn-primary btn-sm mr-2">Editar</a>
                           <!-- Botón Eliminar -->
                           <a href="eliminar_usuario.php?CURP=<?php echo $usuario['CURP']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar este usuario?')">Eliminar</a>
                         </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
