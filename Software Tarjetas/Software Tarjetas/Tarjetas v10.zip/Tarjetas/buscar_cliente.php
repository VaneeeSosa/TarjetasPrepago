<?php
// Datos de conexión a la base de datos
$usuario_bd = 'SYSTEM'; 
$contrasena_bd = '123456'; 
$host = 'localhost'; 
$puerto = '1521'; 
$sid = 'xe'; 

// Conexión a la base de datos
$conexion = oci_connect($usuario_bd, $contrasena_bd, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

if (!$conexion) {
    $error = oci_error();
    die('Error de conexión: ' . $error['message']);
}

// Obtener el número de tarjeta enviado por GET
$numero_tarjeta = isset($_GET['numero_tarjeta']) ? $_GET['numero_tarjeta'] : '';

if ($numero_tarjeta == '') {
    die('Error: No se ha proporcionado un número de tarjeta.');
}

// Query para buscar al cliente por el número de tarjeta
$query = "SELECT c.CURP, c.NombreCom, c.Telefono, c.Direccion, TO_CHAR(c.Vigencia, 'YYYY-MM-DD') AS Vigencia, t.NumeroTarjeta 
          FROM Clientes c 
          INNER JOIN Tarjetas t ON c.CURP = t.CURP 
          WHERE t.NumeroTarjeta = :numero_tarjeta";

$statement = oci_parse($conexion, $query);

if (!$statement) {
    $error = oci_error($conexion);
    die("Error en la preparación de la consulta: " . $error['message']);
}

oci_bind_by_name($statement, ":numero_tarjeta", $numero_tarjeta);
oci_execute($statement);

$datos_cliente = oci_fetch_assoc($statement);

if (!$datos_cliente) {
    die('Error: No se encontraron datos para el número de tarjeta proporcionado.');
}

// Liberar recursos
oci_free_statement($statement);
oci_close($conexion);

// Enviar los datos del cliente como respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($datos_cliente);
?>
