
<?php
session_start();

// Realizar el corte de caja
include 'corte_caja.php';

// Función para redirigir según el rol del usuario
function redirigirSegunRol() {
    // Verifica si hay una sesión activa y el rol del usuario
    if (isset($_SESSION['rol'])) {
        $rol = $_SESSION['rol'];
        
        // Si el usuario es un empleado (rol 1)
        if ($rol == 1) {
            $pagina_actual = basename($_SERVER['PHP_SELF']);
            // Permite acceso solo a 'registro_cliente.php' y 'consulta_clientes.php' para empleados
            if ($pagina_actual != 'registroCliente.php' && $pagina_actual != 'ActualizarUsuario.php' && $pagina_actual != 'BusquedaCliente') {
                header('Location: Error.php'); 
                exit();
            }
        }
    } else {
        // Si no se ha establecido el rol en la sesión, redirigir a la página de inicio de sesión
        header('Location: Login.php');
        exit();
    }
}

// Función para cerrar sesión
function cerrarSesion() {
    // Destruir todas las variables de sesión
    session_destroy();

    // Redirigir al usuario inicio de sesión
    header('Location: Login.php');
    exit();
}

// Verificacion botón de cerrar sesión
if (isset($_POST['cerrar_sesion'])) {
    cerrarSesion();
}

// Llamar a la función de redirección
redirigirSegunRol();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <script src="JS/Escaneo.js"></script>
    <script src="JS/Fotografia.js"></script>
    <title>Registro</title>
</head>
<body>

<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a id="inbox" href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="cerrar_sesion.php">
                    <i class='bx bx-exit'></i>
                       <span>Cerrar sesión</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>
<main>
<div class="row">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card glass-effect" style="width: 28rem;">
      <div class="card-body">
      <h5 class="card-title">Registro cliente</h5>
      <?php if(isset($_GET['alert_message'])): ?>
      <div class="alert alert-<?php echo $_GET['alert_type']; ?>" role="alert">
          <?php echo $_GET['alert_message']; ?>
      </div>
      <?php endif; ?>
      <form method="post" action="registro_cliente.php" onsubmit="return validarFormulario()">
          <label for="curp">CURP:</label>
          <input id="curp" class="form-control inputs" type="text" name="Curp" required>
  
          <label for="nombre">Nombre Completo:</label>
          <input class="form-control inputs" type="text" name="NombreCom">
  
          <label for="telefono">Numero de telefono:</label>
          <input class="form-control inputs" type="text" name="Telefono">
  
          <label for="direccion">Direccion:</label>
          <input class="form-control inputs" type="text" name="Direccion">
  
          <label for="vigencia">Vigencia:</label>
          <input class="form-control inputs" type="date" name="Vigencia">
  
          <label for="monto">Monto total:</label>
          <input class="form-control inputs" type="number" name="Monto" min="0.01" step="0.01" value="1.00" required>
          
          <label for="usuario">Usuario del empleado:</label>
          <input class="form-control inputs" type="text" name="UsuarioEmpleado" required>
  
          <div class="d-flex justify-content-end">
              <input class="btn btn-primary btnEnviar" type="submit" value="Registrar">
          </div>
      </form>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card glass-effect" style="width: 28rem;">
      <div class="card-body">
      <h5 class="card-title">Escaneo de documentos</h5>

      <div class="btn-group-vertical" role="group">
      <button type="button" class="btn btn-primary btnDocs" data-bs-toggle="modal" data-bs-target="#webcamModal" onclick="Fotografia()">Tomar Fotografía</button>
      <button type="button" class="btn btn-primary btnDocs" data-bs-toggle="modal" data-bs-target="#webcamModal2" onclick="documentonombre('INE.png')">Escanear INE</button>
        <button type="button" class="btn btn-primary btnDocs" data-bs-toggle="modal" data-bs-target="#webcamModal2" onclick="documentonombre('CURP.png')">Escanear CURP</button>
        <button type="button" class="btn btn-primary btnDocs" data-bs-toggle="modal" data-bs-target="#webcamModal2" onclick="documentonombre('Comprobante_domicilio.png')">Escanear Comprobante de Domicilio</button>
       </div>
      </div>
    </div>
  </div>
</div>



      <!-- Modal para tomar fotografía -->

      <div class="modal fade" id="webcamModal" tabindex="-1" aria-labelledby="webcamModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="webcamModalLabel">Tomar Fotografía</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <video id="videoCapture" width="100%" autoplay></video>
                <button id="capture" class="btn btn-primary mt-2" onclick="Fotografia()">Capturar</button>
                <canvas id="canvasCapture" style="display:none;"></canvas>
                <!-- Contenedor para mostrar mensajes dentro del modal -->
                <div id="modalMessageContainerCapture" class="alert" role="alert" style="display:none;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
      </div>




<!-- Modal para escanear documento -->
<div class="modal fade" id="webcamModal2" tabindex="-1" aria-labelledby="webcamModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="webcamModalLabel">Escanear Documento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <video id="videoCapture2" width="100%" autoplay></video>
                <button id="capture2" class="btn btn-primary mt-2" onclick="Fotoescaneo()">Capturar</button>
                <canvas id="canvasCapture2" style="display:none;"></canvas>
                <!-- Contenedor para mostrar mensajes dentro del modal -->
                <div id="modalMessageContainer2" class="alert" role="alert" style="display:none;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
      </div>
      </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
