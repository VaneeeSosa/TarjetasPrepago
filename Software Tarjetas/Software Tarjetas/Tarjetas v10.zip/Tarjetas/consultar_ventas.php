<?php
$usuario_bd = 'SYSTEM';
$contrasena_bd = '123456';
$host = 'localhost';
$puerto = '1521';
$sid = 'xe';

$conexion = oci_connect($usuario_bd, $contrasena_bd, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

if (!$conexion) {
    $error = oci_error();
    echo "Error de conexión: " . $error['message'];
    exit();
}

$filter = '';
$bind_params = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreEmpleado = isset($_POST['NombreEmpleado']) ? $_POST['NombreEmpleado'] : '';
    $curpEmpleado = isset($_POST['CurpEmpleado']) ? $_POST['CurpEmpleado'] : '';

    if ($nombreEmpleado) {
        $filter .= " AND u.Nombre LIKE :NombreEmpleado";
        $bind_params[':NombreEmpleado'] = "%$nombreEmpleado%";
    }
    if ($curpEmpleado) {
        $filter .= " AND u.Curp = :CurpEmpleado";
        $bind_params[':CurpEmpleado'] = $curpEmpleado;
    }

    $query = "
        SELECT 
            u.Nombre AS NombreEmpleado, 
            u.Curp AS CurpEmpleado, 
            COUNT(v.IDVenta) AS TotalVentas,
            SUM(v.Monto) AS MontoTotal
        FROM Ventas v
        JOIN Usuarios u ON v.CurpEmpleado = u.Curp
        WHERE TO_CHAR(v.Fecha, 'YYYY-MM-DD') = TO_CHAR(SYSDATE, 'YYYY-MM-DD') $filter
        GROUP BY u.Nombre, u.Curp
    ";

    $statement = oci_parse($conexion, $query);

    foreach ($bind_params as $param => $value) {
        oci_bind_by_name($statement, $param, $value);
    }

    oci_execute($statement);

    if (isset($_POST['generate_pdf'])) {
        require_once 'vendor/autoload.php'; // Asegúrate de tener la librería de PDF instalada (ej. FPDF o TCPDF)

        use Fpdf\Fpdf;

        $pdf = new Fpdf();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, "Ventas del Empleado $curpEmpleado en " . date('Y-m-d'), 0, 1, 'C');

        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(60, 10, "Nombre del Empleado", 1);
        $pdf->Cell(40, 10, "CURP del Empleado", 1);
        $pdf->Cell(40, 10, "Total de Ventas", 1);
        $pdf->Cell(50, 10, "Monto Total", 1);
        $pdf->Ln();

        while ($row = oci_fetch_assoc($statement)) {
            $pdf->Cell(60, 10, $row['NOMBREEMPLEADO'], 1);
            $pdf->Cell(40, 10, $row['CURPEMPLEADO'], 1);
            $pdf->Cell(40, 10, $row['TOTALVENTAS'], 1);
            $pdf->Cell(50, 10, number_format($row['MONTOTOTAL'], 2), 1);
            $pdf->Ln();
        }

        oci_free_statement($statement);
        oci_close($conexion);

        $pdf->Output();
        exit();
    }
} else {
    $query = "
        SELECT 
            u.Nombre AS NombreEmpleado, 
            u.Curp AS CurpEmpleado, 
            COUNT(v.IDVenta) AS TotalVentas,
            SUM(v.Monto) AS MontoTotal
        FROM Ventas v
        JOIN Usuarios u ON v.CurpEmpleado = u.Curp
        WHERE TO_CHAR(v.Fecha, 'YYYY-MM-DD') = TO_CHAR(SYSDATE, 'YYYY-MM-DD')
        GROUP BY u.Nombre, u.Curp
    ";

    $statement = oci_parse($conexion, $query);
    oci_execute($statement);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/tablas.css">
    <title>Consultar Ventas</title>
</head>
<body>
<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a id="inbox" href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="cerrar_sesion.php">
                    <i class='bx bx-exit'></i>
                       <span>Cerrar sesión</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>
<div class="container mt-5">
    <h2>Consulta de Ventas</h2>
    <form method="post" action="consultar_ventas.php" class="mb-3">
        <div class="mb-3">
            <label for="NombreEmpleado" class="form-label">Nombre del Empleado:</label>
            <input type="text" class="form-control" id="NombreEmpleado" name="NombreEmpleado">
        </div>
        <div class="mb-3">
            <label for="CurpEmpleado" class="form-label">CURP del Empleado:</label>
            <input type="text" class="form-control" id="CurpEmpleado" name="CurpEmpleado">
        </div>
        <button type="submit" class="btn btn-primary">Buscar</button>
        <button type="submit" name="generate_pdf" class="btn btn-secondary">Generar PDF</button>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nombre del Empleado</th>
                <th>CURP del Empleado</th>
                <th>Total de Ventas</th>
                <th>Monto Total</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = oci_fetch_assoc($statement)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['NOMBREEMPLEADO']); ?></td>
                    <td><?php echo htmlspecialchars($row['CURPEMPLEADO']); ?></td>
                    <td><?php echo htmlspecialchars($row['TOTALVENTAS']); ?></td>
                    <td>$<?php echo number_format($row['MONTOTOTAL'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="./JS/jsMenu.js"></script>
</body>
</html>

<?php
oci_free_statement($statement);
oci_close($conexion);
?>
