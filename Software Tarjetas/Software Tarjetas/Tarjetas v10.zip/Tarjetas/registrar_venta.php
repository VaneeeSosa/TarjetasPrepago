<?php
include 'Conexion.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $curpEmpleado = $_POST['curpEmpleado'];
    $curpCliente = $_POST['curpCliente'];
    $numeroTarjeta = $_POST['numeroTarjeta'];
    $monto = $_POST['monto'];

    // Verifica que el monto sea un valor positivo
    if ($monto <= 0) {
        echo "El monto debe ser mayor a cero.";
        exit();
    }

    $sql = "INSERT INTO Ventas (IDVenta, Fecha, CurpEmpleado, CurpCliente, NumeroTarjeta, Monto)
            VALUES (Ventas_seq.nextval, SYSDATE, :curpEmpleado, :curpCliente, :numeroTarjeta, :monto)";
    $stmt = oci_parse($conn, $sql);

    oci_bind_by_name($stmt, ':curpEmpleado', $curpEmpleado);
    oci_bind_by_name($stmt, ':curpCliente', $curpCliente);
    oci_bind_by_name($stmt, ':numeroTarjeta', $numeroTarjeta);
    oci_bind_by_name($stmt, ':monto', $monto);

    $result = oci_execute($stmt);

    if ($result) {
        echo "Venta registrada exitosamente.";
    } else {
        $error = oci_error($stmt);
        echo "Error al registrar la venta: " . $error['message'];
    }

    oci_free_statement($stmt);
    oci_close($conn);
}
?>
