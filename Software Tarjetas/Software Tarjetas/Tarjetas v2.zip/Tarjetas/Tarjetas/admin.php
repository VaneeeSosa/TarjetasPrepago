<?php

    session_start();

    // aqui se valida que tipo de rol tiene el usuario y dependiendo de eso lo redirecciona a la pagina correspondiente,
    // ademas no lo deja entrar a otras paginas si no esta logeado.
    if(!isset($_SESSION['rol'])){
        header('location: login.php');
    }else{
        if($_SESSION['rol'] != 1){
            header('location: login.php');
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>
<body>
    <h1>ADMINISTRADOR</h1>
</body>
</html>