<!-- 
    Se debe crear una tabla de roles, donde estara admin y empleado, esta se manejara por los id para asignarlos a 
    los usuarios cada que se registre uno nuevo, admin sera 1 y empleado sera 2, el rol id viajara como fk a la tabla 
    de usuarios para poder hacer la asignacion correspondiente 
 -->
 <?php
// Sesiones
session_start();

// aquí se valida si existe un cerrar sesion, si existe se termina la sesion
if (isset($_GET['cerrar_sesion'])) {
    session_unset();
    session_destroy();
}

// se valida si hay un rol y en caso de hacerlo muestra una pantalla dependiendo del rol que tenga el usuario
if (isset($_SESSION['rol'])) {
    switch ($_SESSION['rol']) {
        case 1:
            header('location: admin.php');
            break;
        case 2:
            header('location: empleado.php');
            break;

        default:
    }
}

// Aqui se autentica al usuario
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // conexion con Oracle
    $usuario = 'SYSTEM';
    $contrasena = '123456';
    $host = 'localhost';
    $puerto = '1521';
    $sid = 'xe';

    // Conexión a la base de datos
    $conexion = oci_connect($usuario, $contrasena, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

    if (!$conexion) {
        $error = oci_error();
        echo "Error de conexión: " . $error['message'];
    } else {
        // consulta SQL
        $query = "SELECT * FROM usuarios WHERE usuario = :username AND contrasena = :password";
        $statement = oci_parse($conexion, $query);

        oci_bind_by_name($statement, ":username", $username);
        oci_bind_by_name($statement, ":password", $password);

        $resultado = oci_execute($statement);

        if ($resultado) {
            // Obtener las filas para verificar si se ha devuelto un resultado o no 
            $num_rows = oci_fetch_all($statement, $resultados);

            if ($num_rows > 0) {
                $rol = $resultados['ROL'][0]; 
                $_SESSION['rol'] = $rol;

                switch ($_SESSION['rol']) {
                    case 1:
                        header('location: admin.php');
                        break;
                    case 2:
                        header('location: empleado.php');
                        break;
                    default:
                        echo "Rol no reconocido.";
                }
            } else {
                echo "El usuario o la contraseña son incorrectos.";
            }
        } else {
            $error = oci_error($statement);
            echo "Error al ejecutar la consulta: " . $error['message'];
        }

        oci_free_statement($statement);

        // Cerrar conexión
        oci_close($conexion);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>
<form action="#" method="POST">
    Nombre de usuario: <br/><input type="text" name="username"><br/>
    Contraseña: <br/><input type="password" name="password"><br/>
    <input type="submit" value="Iniciar Sesion">
</form>
</body>
</html>
