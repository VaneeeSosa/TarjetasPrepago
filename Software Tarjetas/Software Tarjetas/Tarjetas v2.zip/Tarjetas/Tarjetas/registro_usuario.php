<?php
// Datos de conexión a la base de datos Oracle
$usuario = 'SYSTEM';
$contrasena = '12345678';
$host = 'localhost';
$puerto = '1521';
$sid = 'xe';

// Conexión a la base de datos
$conexion = oci_connect($usuario, $contrasena, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

if (!$conexion) {
    $error = oci_error();
    echo "Error de conexión: " . $error['message'];
} else {
    // Recuperar los datos del formulario
    $curp = $_POST['Curp'];
    $nombre = $_POST['NomCompleto'];
    $usuario = $_POST['NomUsuario'];
    $contrasenaUsu = $_POST['Contrasena'];
    $rol = $_POST['Rol'];

    
        // Preparar la consulta SQL para insertar el nuevo usuario
        $query = "INSERT INTO usuarios (curp, nombre, contrasena, rol, usuario) VALUES (:curp ,:nombre, :contrasenaUsu, :rol, :usuario)";

        // Preparar la sentencia
        $statement = oci_parse($conexion, $query);

        // Bind de parámetros
        oci_bind_by_name($statement, ":curp", $curp);
        oci_bind_by_name($statement, ":nombre", $nombre);
        oci_bind_by_name($statement, ":contrasenaUsu", $contrasena);
        oci_bind_by_name($statement, ":rol", $rol);
        oci_bind_by_name($statement, ":usuario", $usuario);

        // Ejecutar la sentencia
        $resultado = oci_execute($statement);

        if ($resultado) {
            echo "Usuario registrado exitosamente.";
        } else {
            $error = oci_error($statement);
            echo "Error al registrar usuario: " . $error['message'];
        }

        // Liberar recursos
        oci_free_statement($statement);

    // Cerrar conexión
    oci_close($conexion);
}
?>
