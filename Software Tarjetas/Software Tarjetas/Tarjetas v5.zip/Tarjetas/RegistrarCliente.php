<HTML>
<head>



</head>
<body>

<form>

<p> CURP: </p>
<input type="text" name="CURP">
<br>
<p> Nombre Completo: </p>
<input type="text" name="NombreCom">
<br>
<p> Numero de Telefono: </p>
<input type="text" name="Telefono">
<br>
<p> Direccion: </p>
<input type="text" name="Direccion">
<br>
<p> Vigencia: </p>
<input type="date" name="Vigencia">
<br>
<p> Tipo de Pago: </p>
<input type="text" name="Pago">
<br>
<p> Monto Total: </p>
<input type="number" id="currencyInput" min="0.01" step="0.01" value="1.00" /><br>
<br>
<button> Tomar Fotografia </button>
<br>
<br>
<button> Escanear CURP </button>
<br>
<br>
<button> Escanear INE </button>
<br>
<br>
<button> Escanear Comprobante Domicilio </button>


</form>

</body>
</HTML>