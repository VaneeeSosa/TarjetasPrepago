<?php
// Sesiones
session_start();

// aquí se valida si existe un cerrar sesion, si existe se termina la sesion
if (isset($_GET['cerrar_sesion'])) {
    session_unset();
    session_destroy();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/admin.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <title>Registro de Usuario</title>
    <script src="JS\ValidacionRegistro.js"></script>
</head>
<body>
<div class="sidebar">
        
        <h2>
        <i class='bx bx-menu' ></i>    
        Menú</h2>
        <a href="#">
        <img src="./img/card1.png" class="iconos">    
        Registrar Tarjeta
        </a>
        <a href="#">
        <img src="./img/card2.png" class="iconos">    
        Renovacion Vigencia
        </a>
        <a href="#">
        <img src="./img/card3.png" class="iconos">    
        Actualizacion Datos
        </a>
        <a href="#">
        <img src="./img/card4.png" class="iconos">
        Restauracion Tarjetas
        </a>
        <a href="#">
        <i class='bx bx-user-pin'></i>    
        Consulta Clientes
        </a>
        <a href="Usuarios.php">
        <i class='bx bxs-user-badge'></i>    
        Consulta Usuarios
        </a>
        <a href="Registro.php">
        <i class='bx bx-user-plus' ></i>    
        Registrar Usuarios
        </a>
        <form action="" method="post">
        <img src="./img/exit.png" class="iconos">
        <button type="submit" name="cerrar_sesion" class="btn">Cerrar sesión</button>
    </form>
    </div>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="card glass-effect border-none" style="width: 52rem;">
            <div class="card-body">
            <h5 class="card-title titulos text-center">Registro de Nuevo Usuario</h5>
            <form method="post" action="registro_usuario.php" onsubmit="return validarFormulario()">
            <label for="nombre">Curp:</label>
            <input class="form-control inputs" type="text" id="Curp" name="Curp" required>

            <label for="nombre">Nombre Completo:</label>
            <input class="form-control inputs" type="text" id="NomCompleto" name="NomCompleto" required>

            <label for="nombre">Nombre de Usuario:</label>
            <input class="form-control inputs" type="text" id="NomUsuario" name="NomUsuario" required>

            <label for="Contrasena">Contraseña:</label>
            <input class="form-control inputs" type="password" id="Contrasena" name="Contrasena" required>

            <label for="confirmar_contrasena">Confirmar Contraseña:</label>
            <input class="form-control inputs" type="password" id="Confirmar_Contrasena" name="Confirmar_Contrasena" required>
            <br>
            <label class="inputs" for="rol">Rol:</label>
            <select class="inputs" id="Rol" name="Rol" required>
                <option class="inputs" value= "1">Empleado</option>
                <option class="inputs" value= "2">Administrador</option>
            </select>
            <br><br>
            <label class="inputs" for="rol">Estatus:</label>
            <select class="inputs" id="Estatus" name="Estatus" required>
                <option class="inputs" value= "1">Activo</option>
                <option class="inputs" value= "2">Inactivo</option>
            </select>
            <div class="d-flex justify-content-end">
            <input class="btn btn-primary btnEnviar" type="submit" value="Registrar">
            </div>
            <div class="container">
                <?php if(isset($alert_message)): ?>
                <div class="alert alert-<?php echo $alert_type; ?>" role="alert">
                    <?php echo $alert_message; ?>
                </div>
                <?php endif; ?>
            </div>

        </form>
        </div>
        </div>
    </div>
</div>




</body>
</html>
