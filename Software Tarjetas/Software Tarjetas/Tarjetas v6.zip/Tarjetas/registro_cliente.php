<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario_bd = 'SYSTEM';
    $contrasena_bd = '123456';
    $host = 'localhost';
    $puerto = '1521';
    $sid = 'xe';

    $conexion = oci_connect($usuario_bd, $contrasena_bd, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

    if (!$conexion) {
        $error = oci_error();
        echo "Error de conexión: " . $error['message'];
    } else {
        $CURP  = isset($_POST['Curp']) ? $_POST['Curp'] : '';
        $NombreCom  = isset($_POST['NombreCom']) ? $_POST['NombreCom'] : '';
        $Telefono  = isset($_POST['Telefono']) ? $_POST['Telefono'] : '';
        $Direccion  = isset($_POST['Direccion']) ? $_POST['Direccion'] : '';
        $Vigencia = isset($_POST['Vigencia']) ? $_POST['Vigencia'] : '';

        if ($Vigencia) {
            $date = DateTime::createFromFormat('Y-m-d', $Vigencia);
            if ($date) {
                $Vigencia = $date->format('d-M-Y');
            } else {
                $Vigencia = '';
            }
        }

        $directory = 'uploads/' . $NombreCom;
        if (!is_dir($directory)) {
            mkdir($directory, 0777, true);
        }

        if (isset($_FILES['ine'])) {
            $inePath = $directory . '/ine.png';
            move_uploaded_file($_FILES['ine']['tmp_name'], $inePath);
        }

        if (isset($_FILES['curp'])) {
            $curpPath = $directory . '/curp.png';
            move_uploaded_file($_FILES['curp']['tmp_name'], $curpPath);
        }

        if (isset($_FILES['comprobante'])) {
            $comprobantePath = $directory . '/comprobante.png';
            move_uploaded_file($_FILES['comprobante']['tmp_name'], $comprobantePath);
        }

        $query = "INSERT INTO Clientes (CURP, NombreCom, Telefono, Direccion, Vigencia) VALUES (:CURP, :NombreCom , :Telefono , :Direccion , TO_DATE(:Vigencia, 'DD-MON-YYYY'))";

        $statement = oci_parse($conexion, $query);

        oci_bind_by_name($statement, ":CURP", $CURP);
        oci_bind_by_name($statement, ":NombreCom", $NombreCom);
        oci_bind_by_name($statement, ":Telefono", $Telefono);
        oci_bind_by_name($statement, ":Direccion", $Direccion);
        oci_bind_by_name($statement, ":Vigencia", $Vigencia);

        $resultado = oci_execute($statement);

        if ($resultado) {
            $alert_message = "Cliente registrado exitosamente.";
            $alert_type = "success";
        } else {
            $error = oci_error($statement);
            $alert_message = "Error al registrar cliente: " . $error['message'];
            $alert_type = "danger";
        }

        oci_free_statement($statement);
        oci_close($conexion);
    }

    header("Location: registro_cliente.php?alert_message=" . urlencode($alert_message) . "&alert_type=" . urlencode($alert_type));
    exit();
}
?>
