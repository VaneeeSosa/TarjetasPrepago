<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/admin.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <title>Registro</title>
</head>
<body>

<div class="sidebar">        
    <h2><i class='bx bx-menu'></i> Menú</h2>
    <a href="#"><img src="./img/card1.png" class="iconos"> Registrar Tarjeta</a>
    <a href="#"><img src="./img/card2.png" class="iconos"> Renovacion Vigencia</a>
    <a href="#"><img src="./img/card3.png" class="iconos"> Actualizacion Datos</a>
    <a href="#"><img src="./img/card4.png" class="iconos"> Restauracion Tarjetas</a>
    <a href="#"><i class='bx bx-user-pin'></i> Consulta Clientes</a>
    <a href="Usuarios.php"><i class='bx bxs-user-badge'></i> Consulta Usuarios</a>
    <a href="Registro.php"><i class='bx bx-user-plus'></i> Registrar Usuarios</a>
    <form action="" method="post">
        <img src="./img/exit.png" class="iconos">
        <button type="submit" name="cerrar_sesion" class="btn">Cerrar sesión</button>
    </form>
</div>

<div class="row">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card glass-effect" style="width: 28rem;">
      <div class="card-body">
      <h5 class="card-title">Registro cliente</h5>
      <?php if(isset($_GET['alert_message'])): ?>
      <div class="alert alert-<?php echo $_GET['alert_type']; ?>" role="alert">
          <?php echo $_GET['alert_message']; ?>
      </div>
      <?php endif; ?>
      <form method="post" action="registro_cliente.php" onsubmit="return validarFormulario()">
          <label class="" for="nombre">CURP:</label>
          <input class="form-control inputs" type="text" name="Curp" required>
  
          <label for="nombre">Nombre Completo:</label>
          <input class="form-control inputs" type="text" name="NombreCom">
  
          <label for="nombre">Numero de telefono:</label>
          <input class="form-control inputs" type="text" name="Telefono">
  
          <label for="nombre">Direccion:</label>
          <input class="form-control inputs" type="text" name="Direccion">
  
          <label for="nombre">Vigencia:</label>
          <input class="form-control inputs" type="date" name="Vigencia">
  
          <label for="nombre">Tipo de pago:</label>
          <input class="form-control inputs" type="text" name="Pago">
  
          <label for="nombre">Monto total:</label>
          <input class="form-control inputs" type="number" id="currencyInput" min="0.01" step="0.01" value="1.00" /><br>
  
          <div class="d-flex justify-content-end">
              <input class="btn btn-primary btnEnviar" type="submit" value="Registrar">
          </div>
      </form>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card glass-effect" style="width: 28rem;">
      <div class="card-body">
      <h5 class="card-title">Escaneo de documentos</h5>

      <div class="btn-group-vertical" role="group">
        <button type="button" class="btn btn-primary btnDocs" data-bs-toggle="modal" data-bs-target="#webcamModal">Tomar Fotografía</button>
        <button type="button" class="btn btn-primary btnDocs">Escanear INE</button>
        <button type="button" class="btn btn-primary btnDocs">Escanear CURP</button>
        <button type="button" class="btn btn-primary btnDocs">Escanear Comprobante de Domicilio</button>
       </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal para la webcam -->
<div class="modal fade" id="webcamModal" tabindex="-1" aria-labelledby="webcamModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="webcamModalLabel">Tomar Fotografía</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <video id="video" width="100%" autoplay></video>
            <button id="capture" class="btn btn-primary mt-2">Capturar</button>
            <canvas id="canvas" style="display:none;"></canvas>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+Cv5HB6yCZp3y5r/tv20+O6aIXofJ" crossorigin="anonymous"></script>
    <script>
      // Script para manejar la webcam
      const video = document.getElementById('video');
      const canvas = document.getElementById('canvas');
      const captureButton = document.getElementById('capture');

      navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
          video.srcObject = stream;
        })
        .catch(err => {
          console.error('Error accessing webcam: ', err);
        });

      captureButton.addEventListener('click', () => {
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/png');

        // Enviar la imagen al servidor
        fetch('save_image.php', {
          method: 'POST',
          body: JSON.stringify({ image: imageData }),
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            alert('Imagen capturada y guardada exitosamente.');
          } else {
            alert('Error al guardar la imagen.');
          }
        })
        .catch(err => console.error('Error enviando la imagen: ', err));
      });
    </script>
</body>
</html>
