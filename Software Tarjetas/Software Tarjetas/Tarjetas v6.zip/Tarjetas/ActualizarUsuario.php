<?php
// Sesiones
session_start();

require_once('Conexion.php');

$con = new Conexion();
$getConnection = $con->Conectar();

// Verificar si se proporciona un ID de usuario para eliminar
if(isset($_GET['CURP'])) {
    // Obtener la CURP del usuario de la URL
    $usuario_curp = $_GET['CURP'];

    try {
        // Preparar la consulta SQL para eliminar el usuario
        $consulta = "SELECT * FROM Usuarios WHERE Curp = :curp";

        // Preparar y ejecutar la consulta
        $stmt = $getConnection->prepare($consulta);
        $stmt->bindParam(':curp', $usuario_curp, PDO::PARAM_STR);
        $stmt->execute();

         // Almacenar resultados en un array asociativo
        $usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Manejar cualquier error de la base de datos
        echo "Error al eliminar el usuario: " . $e->getMessage();
         header("Location: Error.php");
        exit();
    }
} else {
    // Si no se proporciona una CURP de usuario, redirigir al usuario a alguna otra página
    echo "<script>alert('Error al obtener la CURP del usuario');</script>";
    header("Location: Usuario.php");
    exit();
}
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/admin.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <title>Actualizar Usuario</title>
    <script src="JS\ValidacionRegistro.js"></script>
</head>
<body>

<div class="sidebar">
        
        <h2>
        <i class='bx bx-menu' ></i>    
        Menú</h2>
        <a href="#">
        <img src="./img/card1.png" class="iconos">    
        Registrar Tarjeta
        </a>
        <a href="#">
        <img src="./img/card2.png" class="iconos">    
        Renovacion Vigencia
        </a>
        <a href="#">
        <img src="./img/card3.png" class="iconos">    
        Actualizacion Datos
        </a>
        <a href="#">
        <img src="./img/card4.png" class="iconos">
        Restauracion Tarjetas
        </a>
        <a href="#">
        <i class='bx bx-user-pin'></i>    
        Consulta Clientes
        </a>
        <a href="Usuarios.php">
        <i class='bx bxs-user-badge'></i>    
        Consulta Usuarios
        </a>
        <a href="Registro.php">
        <i class='bx bx-user-plus' ></i>    
        Registrar Usuarios
        </a>
        <form action="" method="post">
        <img src="./img/exit.png" class="iconos">
        <button type="submit" name="cerrar_sesion" class="btn">Cerrar sesión</button>
    </form>
    </div>


    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="card glass-effect border-none" style="width: 52rem;">
            <div class="card-body">
                <h5 class="card-title titulos text-center">Actualizar Usuario</h5>
                <form method="post" action="actualizar_usuario.php" onsubmit="return validarFormulario()">
                <label for="nombre">Curp:</label><br>
                <input class="form-control inputs" type="text" id="Curp" name="Curp" required value="<?php echo isset($usuario[0]['CURP']) ? $usuario[0]['CURP'] : ''; ?>"><br><br>

                <label for="nombre">Nombre Completo:</label><br>
                <input class="form-control inputs" type="text" id="NomCompleto" name="NomCompleto" required value="<?php echo isset($usuario[0]['NOMBRE']) ? $usuario[0]['NOMBRE'] : ''; ?>"><br><br>

                <label for="nombre">Nombre de Usuario:</label><br>
                <input class="form-control inputs" type="text" id="NomUsuario" name="NomUsuario" required value="<?php echo isset($usuario[0]['USUARIO']) ? $usuario[0]['USUARIO'] : ''; ?>"><br><br>

                <label for="Contrasena">Contraseña:</label><br>
                <input class="form-control inputs" type="password" id="Contrasena" name="Contrasena" value="<?php echo isset($usuario[0]['CONTRASENA']) ? $usuario[0]['CONTRASENA'] : ''; ?>" required><br><br>

                <label for="confirmar_contrasena">Confirmar Contraseña:</label><br>
                <input class="form-control inputs" type="password" id="Confirmar_Contrasena" name="Confirmar_Contrasena" value="<?php echo isset($usuario[0]['CONTRASENA']) ? $usuario[0]['CONTRASENA'] : ''; ?>" required><br><br>

                <label class="form-control inputs" for="rol">Rol:</label><br>
                <select class="form-control inputs" id="Rol" name="Rol" required>
                    <option value="1" <?php echo isset($usuario[0]['IDROL']) && $usuario[0]['IDROL'] == 1 ? 'selected' : ''; ?>>Empleado</option>
                    <option value="2" <?php echo isset($usuario[0]['IDROL']) && $usuario[0]['IDROL'] == 2 ? 'selected' : ''; ?>>Administrador</option>
                </select><br>

            <label class="form-control inputs" for="estatus">Estatus:</label><br>
            <select class="form-control inputs" id="Estatus" name="Estatus" required>
                <option value="1" <?php echo isset($usuario[0]['IDESTATUS']) && $usuario[0]['IDESTATUS'] == 1 ? 'selected' : ''; ?>>Activo</option>
                <option value="2" <?php echo isset($usuario[0]['IDESTATUS']) && $usuario[0]['IDESTATUS'] == 2 ? 'selected' : ''; ?>>Inactivo</option>
            </select><br><br>

            <div class="d-flex justify-content-end">
                <input class="btn btn-primary btnEnviar" type="submit" value="Actualizar">
            </div>

            <div class="container">
                <?php if(isset($alert_message)): ?>
                <div class="alert alert-<?php echo $alert_type; ?>" role="alert">
                    <?php echo $alert_message; ?>
                </div>
                <?php endif; ?>
            </div>
            </form>

            </div>
            </div>
    </div>
</div>


</body>
</html>
