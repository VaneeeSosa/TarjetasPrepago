use BDTarjetas

ALTER TABLE usuarios (
    Curp VARCHAR2(18) NOT NULL,
    Nombre VARCHAR2(100) NOT NULL,
    Contrasena VARCHAR2(100) NOT NULL,
    Rol VARCHAR2(50) NOT NULL,
     Usuario VARCHAR2(100) NOT NULL,
    CONSTRAINT usuarios_pk PRIMARY KEY (Curp)
);
