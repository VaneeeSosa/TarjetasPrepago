<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista Previa de Tarjeta de Prepago</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>
<body>
    <script>
        async function generarVistaPrevia() {
            const { jsPDF } = window.jspdf;
            
            const response = await fetch('configuracion.json');
            const config = await response.json();
            
            const pdf = new jsPDF({
                orientation: config.orientacion === 'horizontal' ? 'landscape' : 'portrait',
                unit: 'mm',
                format: [85.6, 54] // Tamaño estándar de una tarjeta de crédito
            });

            // Agregar imagen de fondo
            const fondoTarjeta = await fetch(config.fondoTarjeta).then(res => res.blob());
            const fondoTarjetaDataUrl = await convertToDataURL(fondoTarjeta);
            pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 85.6, 54);

            // Establecer el color del texto
            pdf.setTextColor(config.colorTexto);

            const logoWidth = 15; // Reducido
            const logoHeight = 15; // Reducido

            if (config.orientacion === 'horizontal') {
                // Horizontal
                pdf.setFontSize(16);
                pdf.text("Prepago", 70, 10);
                pdf.setFontSize(10);
                pdf.text("Nombre de Ejemplo", 5, 50);
                pdf.text("Tarjeta Prepago", 85, 50, null, null, 'right');
                pdf.addImage(config.logoEmpresa, 'PNG', 5, 5, logoWidth, logoHeight);
                pdf.setFontSize(10);
                pdf.text("Vigencia: 13/02/2004", 5, 45);
            } else {
                // Vertical
                pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 54, 85.6); // Fondo ajustado al tamaño del PDF
                pdf.setFontSize(12);
                pdf.text("Prepago", 5, 10);
                pdf.addImage(config.logoEmpresa, 'PNG', 39, 5, logoWidth, logoHeight, null, 'FAST');
                pdf.setFontSize(10);
                pdf.text("Vigencia: 13/02/2004", 5, 70);
                pdf.setFontSize(16);
                pdf.text("Nombre de Ejemplo", 27, 75, null, null, 'center');
                pdf.setFontSize(10);
                pdf.text("Tarjeta Prepago", 54, 85.6 - 3, null, null, 'right');
            }

            pdf.autoPrint(); // Configura el PDF para imprimir automáticamente
            window.open(pdf.output('bloburl'), '_blank'); // Abre el PDF en una nueva pestaña
        }

        function convertToDataURL(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => resolve(event.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        generarVistaPrevia();
    </script>
</body>
</html>
