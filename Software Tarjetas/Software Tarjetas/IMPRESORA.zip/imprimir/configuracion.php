<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración de Tarjeta de Prepago</title>
    <style>
        .form-container {
            max-width: 600px;
            margin: auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Configuración de Tarjeta de Prepago</h2>
        <form action="configurar.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="logoEmpresa">Logotipo de la Empresa:</label>
                <input type="file" id="logoEmpresa" name="logoEmpresa" class="form-control" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="fondoTarjeta">Imagen de Fondo:</label>
                <input type="file" id="fondoTarjeta" name="fondoTarjeta" class="form-control" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="colorTexto">Color del Texto:</label>
                <input type="color" id="colorTexto" name="colorTexto" class="form-control" value="#000000" required>
            </div>
            <div class="form-group">
                <label for="orientacion">Orientación de la Tarjeta:</label>
                <select id="orientacion" name="orientacion" class="form-control" required>
                    <option value="horizontal">Horizontal</option>
                    <option value="vertical">Vertical</option>
                </select>
            </div>
            <button type="submit">Guardar Configuración</button>
        </form>
        <br>
        <button onclick="vistaPrevia()">Vista Previa</button>
    </div>

    <script>
        function vistaPrevia() {
            window.open('vista_previa.php', '_blank');
        }
    </script>
</body>
</html>
