<?php
// Cargar configuración existente
$configuracion = json_decode(file_get_contents('configuracion.json'), true);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar Tarjeta de Prepago</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        .form-container {
            max-width: 600px;
            margin: auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Información del Cliente</h2>
        <div class="form-group">
            <label for="nombre">Nombre del Cliente:</label>
            <input type="text" id="nombre" class="form-control">
        </div>
        <div class="form-group">
            <label for="vigencia">Fecha de Vigencia:</label>
            <input type="date" id="vigencia" class="form-control">
        </div>
        <button onclick="vistaPrevia()">Vista Previa</button>
        <button onclick="imprimirTarjeta()">Imprimir</button>
    </div>

    <script>
        async function vistaPrevia() {
            await generarPDF(false);
        }

        async function imprimirTarjeta() {
            await generarPDF(true);
        }

        async function generarPDF(autoPrint) {
            const { jsPDF } = window.jspdf;

            const nombre = document.getElementById("nombre").value || "Nombre de Ejemplo";
            const vigencia = document.getElementById("vigencia").value || "13/02/2004";

            const pdf = new jsPDF({
                orientation: '<?php echo $configuracion["orientacion"]; ?>' === 'horizontal' ? 'landscape' : 'portrait',
                unit: 'mm',
                format: [85.6, 54] // Tamaño estándar de una tarjeta de crédito
            });

            // Agregar imagen de fondo
            const fondoTarjeta = await fetch('<?php echo $configuracion["fondoTarjeta"]; ?>').then(res => res.blob());
            const fondoTarjetaDataUrl = await convertToDataURL(fondoTarjeta);
            pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 85.6, 54);

            // Establecer el color del texto
            pdf.setTextColor('<?php echo $configuracion["colorTexto"]; ?>');

            const logoWidth = 15; // Reducido
            const logoHeight = 15; // Reducido

            if ('<?php echo $configuracion["orientacion"]; ?>' === 'horizontal') {
                // Horizontal
                pdf.setFontSize(10);
                pdf.text("Prepago", 70, 10);
                pdf.setFontSize(10);
                pdf.text(nombre, 5, 50);
                pdf.text("Tarjeta Prepago", 85, 50, null, null, 'right');
                pdf.addImage('<?php echo $configuracion["logoEmpresa"]; ?>', 'PNG', 5, 5, logoWidth, logoHeight);
                pdf.setFontSize(12);
                pdf.text(`Vigencia: ${vigencia}`, 5, 45);
            } else {
                // Vertical
                pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 54, 85.6); // Fondo ajustado al tamaño del PDF
                pdf.setFontSize(12);
                pdf.text("Prepago", 5, 10);
                pdf.addImage('<?php echo $configuracion["logoEmpresa"]; ?>', 'PNG', 39, 5, logoWidth, logoHeight, null, 'FAST');
                pdf.setFontSize(8);
                pdf.text(`Vigencia: ${vigencia}`, 5, 70);
                pdf.setFontSize(12);
                pdf.text(nombre, 27, 75, null, null, 'center');
                pdf.setFontSize(8);
                pdf.text("Tarjeta Prepago", 50, 85.6 - 3, null, null, 'right');
            }

            if (autoPrint) {
                pdf.autoPrint();
                window.open(pdf.output('bloburl'), '_blank');
            } else {
                window.open(pdf.output('bloburl'), '_blank');
            }
        }

        function convertToDataURL(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => resolve(event.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }
    </script>
</body>
</html>
