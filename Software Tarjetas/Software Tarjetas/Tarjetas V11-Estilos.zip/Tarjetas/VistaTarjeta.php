<?php
// Cargar configuración existente
$configuracion = json_decode(file_get_contents('configuracion.json'), true);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar Tarjeta de Prepago</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .form-container {
            max-width: 600px;
            margin: auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
    .glass-effect {
    backdrop-filter: blur(10px); 
      background-color: rgba(255, 255, 255, 0.2); 
      padding: 20px;
      border-style: none;
      border-radius: 20px;
      
  }
  .inputs{
    backdrop-filter: blur(10px); 
    background-color: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
    border-style: none;
}
    </style>
</head>
<body>

<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="VistaTarjeta.php">
                        <i class='bx bx-printer' ></i>
                        <span>Impresion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Tarjeta.php">
                        <i class='bx bx-edit-alt'></i>
                        <span>Configuracion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Configuracion.php">
                        <i class='bx bx-cog'></i>
                        <span>Configuracion</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>
    <main>
    <div class="container-fluid">
    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0">
        <div class="card glass-effect" style="width: 28rem;">
        <div class="card-body">
        <h2 class="card-title fw-bold text-center " style="color:#f5daac; font-size:200%;">Información del Cliente</h2>
        <div class="form-group">
            <label for="nombre">Nombre del Cliente:</label>
            <input type="text" id="nombre" class="form-control inputs">
        </div>
        <div class="form-group">
            <label for="vigencia">Fecha de Vigencia:</label>
            <input type="date" id="vigencia" class="form-control inputs">
        </div>

        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <button onclick="vistaPrevia()" class="btnEnviar">Vista Previa</button>
        <button onclick="imprimirTarjeta()" class="btnEnviar">Imprimir</button>
  
        </div>

        </div>
        </div>
        </div>
        </div>
    </div>
    </main>
    <script>
        async function vistaPrevia() {
            await generarPDF(false);
        }

        async function imprimirTarjeta() {
            await generarPDF(true);
        }

        async function generarPDF(autoPrint) {
            const { jsPDF } = window.jspdf;

            const nombre = document.getElementById("nombre").value || "Nombre de Ejemplo";
            const vigencia = document.getElementById("vigencia").value || "13/02/2004";

            const pdf = new jsPDF({
                orientation: '<?php echo $configuracion["orientacion"]; ?>' === 'horizontal' ? 'landscape' : 'portrait',
                unit: 'mm',
                format: [85.6, 54] // Tamaño estándar de una tarjeta de crédito
            });

            // Agregar imagen de fondo
            const fondoTarjeta = await fetch('<?php echo $configuracion["fondoTarjeta"]; ?>').then(res => res.blob());
            const fondoTarjetaDataUrl = await convertToDataURL(fondoTarjeta);
            pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 85.6, 54);

            // Establecer el color del texto
            pdf.setTextColor('<?php echo $configuracion["colorTexto"]; ?>');

            const logoWidth = 15; // Reducido
            const logoHeight = 15; // Reducido

            if ('<?php echo $configuracion["orientacion"]; ?>' === 'horizontal') {
                // Horizontal
                pdf.setFontSize(10);
                pdf.text("Prepago", 70, 10);
                pdf.setFontSize(10);
                pdf.text(nombre, 5, 50);
                pdf.text("Tarjeta Prepago", 85, 50, null, null, 'right');
                pdf.addImage('<?php echo $configuracion["logoEmpresa"]; ?>', 'PNG', 5, 5, logoWidth, logoHeight);
                pdf.setFontSize(12);
                pdf.text(`Vigencia: ${vigencia}`, 5, 45);
            } else {
                // Vertical
                pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 54, 85.6); // Fondo ajustado al tamaño del PDF
                pdf.setFontSize(12);
                pdf.text("Prepago", 5, 10);
                pdf.addImage('<?php echo $configuracion["logoEmpresa"]; ?>', 'PNG', 39, 5, logoWidth, logoHeight, null, 'FAST');
                pdf.setFontSize(8);
                pdf.text(`Vigencia: ${vigencia}`, 5, 70);
                pdf.setFontSize(12);
                pdf.text(nombre, 27, 75, null, null, 'center');
                pdf.setFontSize(8);
                pdf.text("Tarjeta Prepago", 50, 85.6 - 3, null, null, 'right');
            }

            if (autoPrint) {
                pdf.autoPrint();
                window.open(pdf.output('bloburl'), '_blank');
            } else {
                window.open(pdf.output('bloburl'), '_blank');
            }
        }

        function convertToDataURL(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => resolve(event.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }
    </script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
