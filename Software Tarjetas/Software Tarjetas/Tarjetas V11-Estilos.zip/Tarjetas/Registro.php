<?php
// Sesiones
session_start();

// aquí se valida si existe un cerrar sesion, si existe se termina la sesion
if (isset($_GET['cerrar_sesion'])) {
    session_unset();
    session_destroy();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <title>Registro de Usuario</title>
    <script src="JS\ValidacionRegistro.js"></script>
</head>
<body>
<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="VistaTarjeta.php">
                        <i class='bx bx-printer' ></i>
                        <span>Impresion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Tarjeta.php">
                        <i class='bx bx-edit-alt'></i>
                        <span>Configuracion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Configuracion.php">
                        <i class='bx bx-cog'></i>
                        <span>Configuracion</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="card glass-effect border-none" style="width: 52rem;">
            <div class="card-body">
            <h5 class="card-title titulos text-center fw-bold" style="color:#f5daac;">Registro de Nuevo Usuario</h5>
            <form method="post" action="registro_usuario.php" onsubmit="return validarFormulario()">
            <label for="nombre">Curp:</label>
            <input class="form-control inputs" type="text" id="Curp" name="Curp" required>

            <label for="nombre">Nombre Completo:</label>
            <input class="form-control inputs" type="text" id="NomCompleto" name="NomCompleto" required>

            <label for="nombre">Nombre de Usuario:</label>
            <input class="form-control inputs" type="text" id="NomUsuario" name="NomUsuario" required>

            <label for="Contrasena">Contraseña:</label>
            <input class="form-control inputs" type="password" id="Contrasena" name="Contrasena" required>

            <label for="confirmar_contrasena">Confirmar Contraseña:</label>
            <input class="form-control inputs" type="password" id="Confirmar_Contrasena" name="Confirmar_Contrasena" required>
            <br>
            <label class="inputs" for="rol">Rol:</label>
            <select class="inputs" id="Rol" name="Rol" required>
                <option class="inputs" value= "1">Empleado</option>
                <option class="inputs" value= "2">Administrador</option>
            </select>
            <br><br>
            <label class="inputs" for="rol">Estatus:</label>
            <select class="inputs" id="Estatus" name="Estatus" required>
                <option class="inputs" value= "1">Activo</option>
                <option class="inputs" value= "2">Inactivo</option>
            </select>
            <div class="d-flex justify-content-end">
            <input class="btn btn-primary btnEnviar" type="submit" value="Registrar">
            </div>
            <div class="container">
                <?php if(isset($alert_message)): ?>
                <div class="alert alert-<?php echo $alert_type; ?>" role="alert">
                    <?php echo $alert_message; ?>
                </div>
                <?php endif; ?>
            </div>

        </form>
        </div>
        </div>
    </div>
</div>
</main>


<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
