<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Ruta</title>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<style>
    .glass-effect {
    backdrop-filter: blur(10px); 
      background-color: rgba(255, 255, 255, 0.2); 
      padding: 20px;
      border-style: none;
      border-radius: 20px;
      
  }
</style>
<body>
<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="VistaTarjeta.php">
                        <i class='bx bx-printer' ></i>
                        <span>Impresion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Tarjeta.php">
                        <i class='bx bx-edit-alt'></i>
                        <span>Configuracion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Configuracion.php">
                        <i class='bx bx-cog'></i>
                        <span>Configuracion</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>
<main>
    <h1 class="fw-bold mt-4 mb-5" style="color:#f5daac;">Configuracion</h1>
    <br>
    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0">
        <div class="card glass-effect" style="width: 28rem;">
        <div class="card-body">
            <h2>Seleccionar Ruta</h2>
            <form action="guardarruta.php" method="post">
                <label for="ruta">Introduce la ruta de tu computadora:</label>
                <input class="inputs" type="text" name="ruta" id="ruta" required>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <button type="submit" class="btnEnviar">Guardar</button>
                </div>
            </form>
        </div>
        </div>
        </div>
        </div>
    </div>
</main>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
