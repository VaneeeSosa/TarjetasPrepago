<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista Previa de Tarjeta de Prepago</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a id="inbox" href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="VistaTarjeta.php">
                        <i class='bx bx-printer' ></i>
                        <span>Impresion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Tarjeta.php">
                        <i class='bx bx-edit-alt'></i>
                        <span>Configuracion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Configuracion.php">
                        <i class='bx bx-cog'></i>
                        <span>Configuracion</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>
    <main>
    <script>
        async function generarVistaPrevia() {
            const { jsPDF } = window.jspdf;
            
            const response = await fetch('configuracion.json');
            const config = await response.json();
            
            const pdf = new jsPDF({
                orientation: config.orientacion === 'horizontal' ? 'landscape' : 'portrait',
                unit: 'mm',
                format: [85.6, 54] // Tamaño estándar de una tarjeta de crédito
            });

            // Agregar imagen de fondo
            const fondoTarjeta = await fetch(config.fondoTarjeta).then(res => res.blob());
            const fondoTarjetaDataUrl = await convertToDataURL(fondoTarjeta);
            pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 85.6, 54);

            // Establecer el color del texto
            pdf.setTextColor(config.colorTexto);

            const logoWidth = 15; // Reducido
            const logoHeight = 15; // Reducido

            if (config.orientacion === 'horizontal') {
                // Horizontal
                pdf.setFontSize(16);
                pdf.text("Prepago", 70, 10);
                pdf.setFontSize(10);
                pdf.text("Nombre de Ejemplo", 5, 50);
                pdf.text("Tarjeta Prepago", 85, 50, null, null, 'right');
                pdf.addImage(config.logoEmpresa, 'PNG', 5, 5, logoWidth, logoHeight);
                pdf.setFontSize(10);
                pdf.text("Vigencia: 13/02/2004", 5, 45);
            } else {
                // Vertical
                pdf.addImage(fondoTarjetaDataUrl, 'PNG', 0, 0, 54, 85.6); // Fondo ajustado al tamaño del PDF
                pdf.setFontSize(12);
                pdf.text("Prepago", 5, 10);
                pdf.addImage(config.logoEmpresa, 'PNG', 39, 5, logoWidth, logoHeight, null, 'FAST');
                pdf.setFontSize(10);
                pdf.text("Vigencia: 13/02/2004", 5, 70);
                pdf.setFontSize(16);
                pdf.text("Nombre de Ejemplo", 27, 75, null, null, 'center');
                pdf.setFontSize(10);
                pdf.text("Tarjeta Prepago", 54, 85.6 - 3, null, null, 'right');
            }

            pdf.autoPrint(); // Configura el PDF para imprimir automáticamente
            window.open(pdf.output('bloburl'), '_blank'); // Abre el PDF en una nueva pestaña
        }

        function convertToDataURL(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => resolve(event.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        generarVistaPrevia();
    </script>
    </main>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
