function validarFormulario() {
    var curp = document.getElementById("Curp").value;
    var nombre = document.getElementById("NomCompleto").value;
    var usuario = document.getElementById("NomUsuario").value;
    var contrasena = document.getElementById("Contrasena").value;
    var confirmar_contrasena = document.getElementById("Confirmar_Contrasena").value;

    // Convertir CURP a mayúsculas
    curp = curp.toUpperCase();

    // Verificar si los campos están vacíos
    if (curp === "" || nombre === "" || usuario === "" || contrasena === "" || confirmar_contrasena === "") {
        alert("Por favor, complete todos los campos del formulario.");
        return false;
    }

    // Verificar longitud de los campos
    if (curp.length !== 18) {
        alert("El campo CURP debe tener 18 caracteres.");
        return false;
    }

    if (nombre.length > 100) {
        alert("El campo Nombre debe tener como máximo 100 caracteres.");
        return false;
    }

    if (usuario.length > 100) {
        alert("El campo Usuario debe tener como máximo 100 caracteres.");
        return false;
    }

    // Verificar que CURP y nombre no contengan números o caracteres especiales
    var curpRegex = /^[A-Z0-9]+$/;
    if (!curpRegex.test(curp)) {
        alert("Corrobore su informacion del CURP.");
        return false;
    }

    var nombreRegex = /^[A-Za-z\s]+$/;
    if (!nombreRegex.test(nombre)) {
        alert("El campo Nombre solo debe contener letras.");
        return false;
    }

    // Verificar longitud de contraseña y si contiene caracteres especiales
    if (contrasena.length < 8 || contrasena.length > 32) {
        alert("La contraseña debe tener entre 8 y 32 caracteres.");
        return false;
    }

    // Verificar si las contraseñas coinciden
    if (contrasena !== confirmar_contrasena) {
        alert("Las contraseñas no coinciden, corrobore su información.");
        return false;
    }

    return true;
}