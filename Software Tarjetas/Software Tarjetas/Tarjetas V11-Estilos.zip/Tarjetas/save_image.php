<?php
// Configura la respuesta para que sea JSON
header('Content-Type: application/json');

//Nombre de la imagen
$imageName = 'Fotografia.png'; // Nombre completo con extensión

// Verifica si se está recibiendo una solicitud POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtiene el contenido JSON de la solicitud
    $data = json_decode(file_get_contents('php://input'), true);

    // Verifica si la decodificación del JSON fue exitosa
    if (json_last_error() === JSON_ERROR_NONE) {
        // Verifica si los datos necesarios están presentes en el JSON recibido
        if (isset($data['image']) && isset($data['curp'])) {
            // Obtiene el CURP y la imagen desde el JSON
            $curp = $data['curp'];
            $imageData = $data['image'];

            // Directorio base donde se guardarán las imágenes (ajústalo según tu necesidad)
            $baseDir = 'C:\\Users\\empan\\OneDrive\\Documentos';

            // Ruta completa para el directorio del CURP
            $directoryPath = $baseDir . DIRECTORY_SEPARATOR . $curp;

            // Verifica si el directorio ya existe
            if (!file_exists($directoryPath)) {
                // Intenta crear el directorio si no existe
                if (!mkdir($directoryPath, 0777, true)) {
                    echo json_encode(['success' => false, 'message' => "Error al crear el directorio '$curp'."]);
                    exit;
                }
            }

            // Ruta completa del archivo de imagen
            $imagePath = $directoryPath . DIRECTORY_SEPARATOR . $imageName;

            // Verifica si el archivo de imagen ya existe en el directorio
            if (file_exists($imagePath)) {
                echo json_encode(['success' => false, 'message' => 'Ya existe una imagen con este nombre para el CURP proporcionado.']);
                exit;
            }

            // Decodifica los datos de la imagen base64 y guarda la imagen
            $imageData = str_replace('data:image/png;base64,', '', $imageData);
            $imageData = str_replace(' ', '+', $imageData);
            $imageData = base64_decode($imageData);

            // Guarda la imagen en el directorio especificado
            if (file_put_contents($imagePath, $imageData)) {
                // Éxito al guardar la imagen
                echo json_encode(['success' => true, 'message' => 'Imagen guardada exitosamente.']);
            } else {
                // Error al guardar la imagen
                echo json_encode(['success' => false, 'message' => 'Error al guardar la imagen.']);
            }
        } else {
            // Error si no se recibieron datos válidos
            echo json_encode(['success' => false, 'message' => 'Error: datos de imagen y/o CURP no recibidos correctamente.']);
        }
    } else {
        // Error en la decodificación del JSON
        echo json_encode(['success' => false, 'message' => 'Error al decodificar los datos JSON.']);
    }
} else {
    // Error si no se utilizó el método POST
    echo json_encode(['success' => false, 'message' => 'Método HTTP no permitido.']);
}
?>
