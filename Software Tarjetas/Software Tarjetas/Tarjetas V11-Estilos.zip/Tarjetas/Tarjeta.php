<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración de Tarjeta de Prepago</title>
    <link rel="stylesheet" href="./css/menu.css">
    <link rel="stylesheet" href="./css/formularios.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <style>
        .form-container {
            max-width: 600px;
            margin: auto;
        }
        .form-group {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="menu">
        <ion-icon name="menu-outline"></ion-icon>
        <ion-icon name="close-outline"></ion-icon>
    </div>

    <div class="barra-lateral">
        <div>
            <div class="nombre-pagina">
                <ion-icon id="cloud" name="cloud-outline"></ion-icon>
                <span>TI@TT</span>
            </div>
        </div>

        <nav class="navegacion">
            <ul>
                <li>
                    <a href="RegistroCliente.php">
                        <i class='bx bx-id-card'></i>
                        <span>Registrar tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="BusquedaCliente.php">
                        <i class='bx bx-user-pin'></i>
                        <span>Consulta Clientes</span>
                    </a>
                </li>
                <li>
                    <a href="Registro.php">
                        <i class='bx bx-user-plus'></i>
                        <span>Registrar Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="Usuarios.php">
                        <i class='bx bxs-user-badge'></i>
                        <span>Consulta Usuarios</span>
                    </a>
                </li>
                <li>
                    <a href="VistaTarjeta.php">
                        <i class='bx bx-printer' ></i>
                        <span>Impresion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Tarjeta.php">
                        <i class='bx bx-edit-alt'></i>
                        <span>Configuracion Tarjeta</span>
                    </a>
                </li>
                <li>
                    <a href="Configuracion.php">
                        <i class='bx bx-cog'></i>
                        <span>Configuracion</span>
                    </a>
                </li>
                
            </ul>
        </nav>
    </div>

<main>
    <div class="form-container">
        <h2 class="fw-bold mt-4 mb-5" style="color:#f5daac;">Configuración de Tarjeta de Prepago</h2>
        
        <form action="configurar_tarjeta.php" method="post" enctype="multipart/form-data" class="mt-2">
            <div class="form-group">
                <label for="logoEmpresa" >Logotipo de la Empresa:</label>
                <input type="file" id="logoEmpresa" name="logoEmpresa" class="form-control inputs" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="fondoTarjeta">Imagen de Fondo:</label>
                <input type="file" id="fondoTarjeta" name="fondoTarjeta" class="form-control inputs" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="colorTexto">Color del Texto:</label>
                <input type="color" id="colorTexto" name="colorTexto" class="form-control inputs" value="#000000" required>
            </div>
            <div class="form-group">
                <label for="orientacion">Orientación de la Tarjeta:</label>
                <select id="orientacion" name="orientacion" class="form-control inputs" required>
                    <option value="horizontal">Horizontal</option>
                    <option value="vertical">Vertical</option>
                </select>
            </div>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button type="submit" class="btnEnviar" style="width: 100px; height: 70px; color:white;">Guardar Configuración</button>
            <button onclick="vistaPrevia()" class="btnEnviar" style="width: 100px; height: 70px; color:white;">Vista Previa</button>
            </div>

        </form>
    </div>
    </main>
    <script>
        function vistaPrevia() {
            window.open('vista_previa.php', '_blank');
        }
    </script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="./JS/jsMenu.js"></script>
</body>
</html>
