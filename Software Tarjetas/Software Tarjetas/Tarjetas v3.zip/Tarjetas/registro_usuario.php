<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Datos de conexión a la base de datos Oracle
    $usuario_bd = 'SYSTEM';
    $contrasena_bd = '1234567';
    $host = 'localhost';
    $puerto = '1521';
    $sid = 'xe';

    // Conexión a la base de datos
    $conexion = oci_connect($usuario_bd, $contrasena_bd, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

    if (!$conexion) {
        $error = oci_error();
        echo "Error de conexión: " . $error['message'];
    } else {
        // Recuperar los datos del formulario
        $curp = isset($_POST['Curp']) ? $_POST['Curp'] : '';
        $nombre = isset($_POST['NomCompleto']) ? $_POST['NomCompleto'] : '';
        $usuario_form = isset($_POST['NomUsuario']) ? $_POST['NomUsuario'] : '';
        $contrasena = isset($_POST['Contrasena']) ? $_POST['Contrasena'] : '';
        $rol = isset($_POST['Rol']) ? $_POST['Rol'] : '';
        $estatus = isset($_POST['Estatus']) ? $_POST['Estatus'] : '';

        // Preparar la consulta SQL para insertar el nuevo usuario
        $query = "INSERT INTO Usuarios (Curp, Nombre, Contrasena, IDROL, IDESTATUS, Usuario) VALUES (:curp, :nombre, :contrasena, :rol, :estatus, :usuario)";

        // Preparar la sentencia
        $statement = oci_parse($conexion, $query);

        // Bind de parámetros
        oci_bind_by_name($statement, ":curp", $curp);
        oci_bind_by_name($statement, ":nombre", $nombre);
        oci_bind_by_name($statement, ":contrasena", $contrasena);
        oci_bind_by_name($statement, ":rol", $rol);
        oci_bind_by_name($statement, ":estatus", $estatus);
        oci_bind_by_name($statement, ":usuario", $usuario_form);

        // Ejecutar la sentencia
        $resultado = oci_execute($statement);

        if ($resultado) {
            echo "Usuario registrado exitosamente.";
        } else {
            $error = oci_error($statement);
            echo "Error al registrar usuario: " . $error['message'];
        }

        // Liberar recursos
        oci_free_statement($statement);

        // Cerrar conexión
        oci_close($conexion);
    }
}
?>
