<?php
// Sesiones
session_start();

// Incluir el archivo de conexión
require_once('Conexion.php');

// Crear una instancia de la clase de conexión
$conexion = new Conexion();
$getConnection = $conexion->Conectar();

// Comprobar si se ha solicitado cerrar sesión
if (isset($_GET['cerrar_sesion'])) {
    session_unset();
    session_destroy();
}

// Redirigir al usuario según su rol si ya está autenticado
if (isset($_SESSION['rol'])) {
    switch ($_SESSION['rol']) {
        case 1:
            header('location: Empleado.php');
            exit();
        case 2:
            header('location: Administrador.php');
            exit();
    }
}

// Autenticar al usuario si se han enviado datos de inicio de sesión
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Preparar la consulta SQL
    $sql = "SELECT * FROM Usuarios WHERE Usuario = :username AND Contrasena = :password";
    $stmt = $getConnection->prepare($sql);
    
    // Asignar valores a los parámetros y ejecutar la consulta
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();

    // Obtener el resultado
    $resultados = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($resultados) {
       // Obtener el rol del usuario y establecerlo en la sesión
$rol = $resultados['IDROL'];
$estatus = $resultados['IDESTATUS'];
$_SESSION['rol'] = $rol;

// Verificar el estado del usuario
if ($estatus === '1') {
    // Redirigir al usuario según su rol
    switch ($_SESSION['rol']) {
        case 1:
            header('location: empleado.php');
            exit();
        case 2:
            header('location: admin.php');
            exit();
        default:
            header('location: Login.php');
            exit();
    }
} else {
    // Usuario inactivo
    echo "Usuario inactivo";
}

    } else {
        echo "El usuario o la contraseña son incorrectos.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>
<form action="#" method="POST">
    Nombre de usuario: <br/><input type="text" name="username"><br/>
    Contraseña: <br/><input type="password" name="password"><br/>
    <input type="submit" value="Iniciar Sesion">
</form>
</body>
</html>
