<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexión a la base de datos (ya establecida en tu código)
    $usuario_bd = 'SYSTEM';
    $contrasena_bd = '123456';
    $host = 'localhost';
    $puerto = '1521';
    $sid = 'xe';

    $conexion = oci_connect($usuario_bd, $contrasena_bd, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

    if (!$conexion) {
        $error = oci_error();
        echo "Error de conexión: " . $error['message'];
    } else {
        // Recuperar datos del formulario
        $CURP = isset($_POST['Curp']) ? $_POST['Curp'] : '';
        $NombreCom = isset($_POST['NombreCom']) ? $_POST['NombreCom'] : '';
        $Telefono = isset($_POST['Telefono']) ? $_POST['Telefono'] : '';
        $Direccion = isset($_POST['Direccion']) ? $_POST['Direccion'] : '';
        $Vigencia = isset($_POST['Vigencia']) ? $_POST['Vigencia'] : '';
        $Pago = isset($_POST['Pago']) ? $_POST['Pago'] : '';
        $imagen = isset($_POST['imagen']) ? $_POST['imagen'] : '';

        // Procesar la vigencia para formato de base de datos
        if ($Vigencia) {
            $date = DateTime::createFromFormat('Y-m-d', $Vigencia);
            if ($date) {
                $Vigencia = $date->format('d-M-Y');
            } else {
                $Vigencia = '';
            }
        }

        // Crear directorio para guardar archivos (si no existe)
        $directory = 'uploads/' . $NombreCom;
        if (!is_dir($directory)) {
            mkdir($directory, 0777, true);
        }

        // Guardar la imagen capturada (ejemplo basado en tu implementación)
        if ($imagen) {
            $imagen = str_replace('data:image/png;base64,', '', $imagen);
            $imagen = str_replace(' ', '+', $imagen);
            $imagenData = base64_decode($imagen);
            $imagenPath = $directory . '/foto.png';
            file_put_contents($imagenPath, $imagenData);
        }

        // Insertar datos del cliente en la tabla Clientes
        $queryClientes = "INSERT INTO Clientes (CURP, NombreCom, Telefono, Direccion, Vigencia) 
                          VALUES (:CURP, :NombreCom, :Telefono, :Direccion, TO_DATE(:Vigencia, 'DD-MON-YYYY'))";
        
        $statementClientes = oci_parse($conexion, $queryClientes);

        oci_bind_by_name($statementClientes, ":CURP", $CURP);
        oci_bind_by_name($statementClientes, ":NombreCom", $NombreCom);
        oci_bind_by_name($statementClientes, ":Telefono", $Telefono);
        oci_bind_by_name($statementClientes, ":Direccion", $Direccion);
        oci_bind_by_name($statementClientes, ":Vigencia", $Vigencia);

        $resultadoClientes = oci_execute($statementClientes);

        // Obtener el último ID insertado (en caso de ser necesario)
        // $idCliente = oci_last_insert_id($conexion);

        // Insertar datos de la tarjeta en la tabla Tarjetas
        $NumeroTarjeta = isset($_POST['Tarjeta']) ? $_POST['Tarjeta'] : '';

        $queryTarjetas = "INSERT INTO Tarjetas (NumeroTarjeta, CURP, FechaEmision) 
                          VALUES (:NumeroTarjeta, :CURP, SYSDATE)";
        
        $statementTarjetas = oci_parse($conexion, $queryTarjetas);

        oci_bind_by_name($statementTarjetas, ":NumeroTarjeta", $NumeroTarjeta);
        oci_bind_by_name($statementTarjetas, ":CURP", $CURP);

        $resultadoTarjetas = oci_execute($statementTarjetas);

        // Verificar si se ejecutaron correctamente ambas consultas
        if ($resultadoClientes && $resultadoTarjetas) {
            $alert_message = "Cliente registrado exitosamente.";
            $alert_type = "success";
        } else {
            $errorClientes = oci_error($statementClientes);
            $errorTarjetas = oci_error($statementTarjetas);
            $alert_message = "Error al registrar cliente: " . $errorClientes['message'] . " | Error de tarjeta: " . $errorTarjetas['message'];
            $alert_type = "danger";
        }

        oci_free_statement($statementClientes);
        oci_free_statement($statementTarjetas);
        oci_close($conexion);
    }

    // Redireccionar con mensaje de alerta
    header("Location: registro_cliente.php?alert_message=" . urlencode($alert_message) . "&alert_type=" . urlencode($alert_type));
    exit();
}
?>
