<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = 'uploads/';

    // Verificar si el directorio 'uploads' existe, si no, crearlo
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Manejar el logotipo de la empresa
    $logoEmpresa = $uploadDir . basename($_FILES['logoEmpresa']['name']);
    if (move_uploaded_file($_FILES['logoEmpresa']['tmp_name'], $logoEmpresa)) {
        echo 'Logotipo de la empresa subido correctamente.<br>';
    } else {
        echo 'Error al subir el logotipo de la empresa.<br>';
    }

    // Manejar la imagen de fondo
    $fondoTarjeta = $uploadDir . basename($_FILES['fondoTarjeta']['name']);
    if (move_uploaded_file($_FILES['fondoTarjeta']['tmp_name'], $fondoTarjeta)) {
        echo 'Imagen de fondo subida correctamente.<br>';
    } else {
        echo 'Error al subir la imagen de fondo.<br>';
    }

    // Obtener el color del texto y la orientación
    $colorTexto = $_POST['colorTexto'];
    $orientacion = $_POST['orientacion'];

    // Guardar la configuración en un archivo JSON
    $configuracion = [
        'logoEmpresa' => $logoEmpresa,
        'fondoTarjeta' => $fondoTarjeta,
        'colorTexto' => $colorTexto,
        'orientacion' => $orientacion
    ];
    file_put_contents('configuracion.json', json_encode($configuracion));

    echo 'Configuración guardada con éxito.';
}
?>
