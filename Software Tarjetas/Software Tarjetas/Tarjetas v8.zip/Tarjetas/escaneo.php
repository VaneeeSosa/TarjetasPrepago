<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluye el archivo de configuración (RUTA)
require_once 'config.php';

// Usa la constante BASE_PATH
$baseDir = BASE_PATH ;

// Verificar que Imagick esté instalado
if (!extension_loaded('imagick')) {
    file_put_contents('debug_log.txt', "Imagick no está instalado\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => 'Imagick is not installed']);
    exit;
}

// Obtener los datos de la imagen
$data = json_decode(file_get_contents('php://input'), true);
file_put_contents('debug_log.txt', "Datos recibidos: " . print_r($data, true) . "\n", FILE_APPEND);

if (json_last_error() !== JSON_ERROR_NONE) {
    file_put_contents('debug_log.txt', "Error al decodificar JSON: " . json_last_error_msg() . "\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

$image = $data['image'];
$curp = $data['curp'];
$documento = $data['nombre'];

if (!$image || !$curp) {
    file_put_contents('debug_log.txt', "No se encontraron datos de la imagen y/o CURP\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => 'No image data or CURP found']);
    exit;
}

// Eliminar el encabezado de los datos base64
$image = str_replace('data:image/png;base64,', '', $image);
$image = str_replace(' ', '+', $image);
$imageData = base64_decode($image);

// Verificar si se decodificó correctamente
if ($imageData === false) {
    file_put_contents('debug_log.txt', "Error al decodificar la imagen\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => 'Failed to decode image']);
    exit;
}

// Ruta completa para el directorio del CURP
$directoryPath = $baseDir . DIRECTORY_SEPARATOR . $curp;

// Verifica si el directorio ya existe
if (!file_exists($directoryPath)) {
    // Intenta crear el directorio si no existe
    if (!mkdir($directoryPath, 0777, true)) {
        file_put_contents('debug_log.txt', "Error al crear el directorio '$curp'\n", FILE_APPEND);
        echo json_encode(['status' => 'error', 'message' => "Error al crear el directorio '$curp'."]);
        exit;
    }
}

// Genera un nombre único para la imagen (puedes ajustarlo según tus necesidades)
$imageName = $documento;

// Ruta completa del archivo de imagen
$imagePath = $directoryPath . DIRECTORY_SEPARATOR . $imageName;

// Verifica si ya existe un archivo con el mismo nombre
if (file_exists($imagePath)) {
    echo json_encode(['status' => 'error', 'message' => 'Error: Ya existe una imagen con este nombre.']);
    exit;
}

// Guardar la imagen temporalmente
$tempFileName = __DIR__ . '/temp.png';
if (file_put_contents($tempFileName, $imageData) === false) {
    file_put_contents('debug_log.txt', "Error al escribir la imagen en el archivo temporal\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => 'Failed to write image to temp file']);
    exit;
}

// Procesar la imagen usando Imagick
try {
    $imagick = new Imagick($tempFileName);
    
    // Convertir a escala de grises
    $imagick->setImageColorspace(Imagick::COLORSPACE_GRAY);

    // Ajustar el contraste suavemente
    $imagick->contrastImage(1); // Ajuste de contraste

    // Aumentar el brillo en un 15% adicional
    $imagick->brightnessContrastImage(15, 20); // Ajuste de brillo (+15%) y contraste

    // Aplicar un filtro de desenfoque suave para mantener detalles
    $imagick->adaptiveBlurImage(1, 0.5);

    // Guardar la imagen procesada en el directorio especificado
    $imagick->writeImage($imagePath);
    $imagick->clear();
    $imagick->destroy();

    // Eliminar el archivo temporal
    unlink($tempFileName);

    // Éxito al guardar la imagen
    echo json_encode(['status' => 'success', 'message' => 'Imagen procesada y guardada exitosamente.']);
    file_put_contents('debug_log.txt', "Imagen procesada y guardada en '$imagePath'\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents('debug_log.txt', "Error: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
