<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Datos de conexión a la base de datos Oracle
    $usuario_bd = 'SYSTEM';
    $contrasena_bd = '1234567';
    $host = 'localhost';
    $puerto = '1521';
    $sid = 'xe';

    // Conexión a la base de datos
    $conexion = oci_connect($usuario_bd, $contrasena_bd, "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$host)(PORT=$puerto))(CONNECT_DATA=(SID=$sid)))");

    if (!$conexion) {
        $error = oci_error();
        echo "Error de conexión: " . $error['message'];
    } else {
        // Recuperar los datos del formulario
        $curp = isset($_POST['Curp']) ? $_POST['Curp'] : '';
        $nombre = isset($_POST['NomCompleto']) ? $_POST['NomCompleto'] : '';
        $usuario_form = isset($_POST['NomUsuario']) ? $_POST['NomUsuario'] : '';
        $contrasena = isset($_POST['Contrasena']) ? $_POST['Contrasena'] : '';
        $rol = isset($_POST['Rol']) ? $_POST['Rol'] : '';
        $estatus = isset($_POST['Estatus']) ? $_POST['Estatus'] : '';

        // Preparar la consulta SQL para actualizar el usuario
        $query = "UPDATE Usuarios 
                  SET Nombre = :nombre, 
                      Contrasena = :contrasena, 
                      IDROL = :rol, 
                      IDESTATUS = :estatus, 
                      Usuario = :usuario 
                  WHERE Curp = :curp";

        // Preparar la sentencia
        $statement = oci_parse($conexion, $query);

        // Bind de parámetros
        oci_bind_by_name($statement, ":curp", $curp);
        oci_bind_by_name($statement, ":nombre", $nombre);
        oci_bind_by_name($statement, ":contrasena", $contrasena);
        oci_bind_by_name($statement, ":rol", $rol);
        oci_bind_by_name($statement, ":estatus", $estatus);
        oci_bind_by_name($statement, ":usuario", $usuario_form);

        // Ejecutar la sentencia
        $resultado = oci_execute($statement);

        if ($resultado) {
            $alert_message = "Usuario actualizado exitosamente.";
            $alert_type = "success";
        } else {
            $error = oci_error($statement);
            $alert_message = "Error al actualizar usuario: " . $error['message'];
            $alert_type = "danger";
        }

        // Liberar recursos
        oci_free_statement($statement);

        // Cerrar conexión
        oci_close($conexion);
    }
}
?>
