<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Ruta</title>
</head>
<body>
    <h1>Seleccionar Ruta</h1>
    <form action="guardarruta.php" method="post">
        <label for="ruta">Introduce la ruta de tu computadora:</label>
        <input type="text" name="ruta" id="ruta" required>
        <button type="submit">Guardar Ruta</button>
    </form>
</body>
</html>
