function Fotografia() {
    // Script para manejar la webcam
    const video = document.getElementById('videoCapture');
    const canvas = document.getElementById('canvasCapture');
    const captureButton = document.getElementById('capture');
    const modalMessageContainer = document.getElementById('modalMessageContainerCapture');

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
        })
        .catch(err => {
            console.error('Error accessing webcam: ', err);
            alert('Error accessing webcam: ' + err.message);
        });

    captureButton.addEventListener('click', () => {
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/png');

        // Obtener el valor del CURP del input
        const curp = document.getElementById('curp').value;

        // Enviar la imagen al servidor
        fetch('./save_image.php', {
            method: 'POST',
            body: JSON.stringify({ image: imageData, curp: curp }), // Incluir CURP en los datos enviados
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                modalMessageContainer.className = 'alert alert-success';
                modalMessageContainer.textContent = 'Imagen capturada y guardada exitosamente.';
            } else {
                modalMessageContainer.className = 'alert alert-danger';
                modalMessageContainer.textContent = data.message; // Mostrar mensaje de error específico
            }
            modalMessageContainer.style.display = 'block';
        })
        .catch(err => {
            modalMessageContainer.className = 'alert alert-danger';
            modalMessageContainer.textContent = 'Error enviando la imagen.';
            modalMessageContainer.style.display = 'block';
            console.error('Error enviando la imagen: ', err);
            alert('Error enviando la imagen: ' + err.message);
        });
    });
}
