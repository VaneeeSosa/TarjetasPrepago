<?php
// config.php
if (file_exists('ruta.txt')) {
    define('BASE_PATH', trim(file_get_contents('ruta.txt')));
} else {
    define('BASE_PATH', '');
}
?>
