<?php
session_start();
// Función para redirigir según el rol del usuario
function redirigirSegunRol() {
    if (isset($_SESSION['rol'])) {
        if ($_SESSION['rol'] == 2) {
            // Si el rol es 1, el usuario es un Administrador, no realiza ninguna accion

        } elseif ($_SESSION['rol'] == 1) {
            // Si el rol es 1, el usuario es un Empleado, redirigir a la página de Empleado
            header('Location: Empleado.php');
            exit();
        }
    } else {
        // Si no se ha establecido el rol en la sesión, redirigir a la página de inicio de sesión
        header('Location: Login.php');
        exit();
    }
}

// Función para cerrar sesión
function cerrarSesion() {
    // Destruir todas las variables de sesión
    session_destroy();
    // Redirigir al usuario a la página de inicio de sesión
    header('Location: login.php');
    exit();
}

// Verificar si se hizo clic en el botón de cerrar sesión
if (isset($_POST['cerrar_sesion'])) {
    cerrarSesion();
}

redirigirSegunRol();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./css/admin.css">
    <title>Admin</title>
</head>
<body>

    <div class="sidebar">
        
        <h2>
        <i class='bx bx-menu' ></i>    
        Menú</h2>
        <a href="#">
        <img src="./img/card1.png" class="iconos">    
        Registrar Tarjeta
        </a>
        <a href="#">
        <img src="./img/card2.png" class="iconos">    
        Renovacion Vigencia
        </a>
        <a href="#">
        <img src="./img/card3.png" class="iconos">    
        Actualizacion Datos
        </a>
        <a href="#">
        <img src="./img/card4.png" class="iconos">
        Restauracion Tarjetas
        </a>
        <a href="#">
        <i class='bx bx-user-pin'></i>    
        Consulta Clientes
        </a>
        <a href="Usuarios.php">
        <i class='bx bxs-user-badge'></i>    
        Consulta Usuarios
        </a>
        <a href="Registro.php">
        <i class='bx bx-user-plus' ></i>    
        Registrar Usuarios
        </a>
        <form action="" method="post">
        <img src="./img/exit.png" class="iconos">
        <button type="submit" name="cerrar_sesion" class="btn">Cerrar sesión</button>
    </form>
    </div>
    <img src="./img/logo.png" class=""> 

</body>
</html>
