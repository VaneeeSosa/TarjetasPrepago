<?php
include 'Conexion.php'; 


$fecha = date('Y-m-d');

$sql = "SELECT CurpEmpleado, SUM(Monto) AS TotalVentas
        FROM Ventas
        WHERE TO_CHAR(Fecha, 'YYYY-MM-DD') = :fecha
        GROUP BY CurpEmpleado";
$stmt = oci_parse($conn, $sql);

oci_bind_by_name($stmt, ':fecha', $fecha);

oci_execute($stmt);

echo "<h1>Corte de Caja para el $fecha</h1>";
echo "<table border='1'>
        <tr>
            <th>CurpEmpleado</th>
            <th>TotalVentas</th>
        </tr>";

while ($row = oci_fetch_assoc($stmt)) {
    echo "<tr>
            <td>" . $row['CURPEMPLEADO'] . "</td>
            <td>" . $row['TOTALVENTAS'] . "</td>
          </tr>";
}

echo "</table>";

oci_free_statement($stmt);
oci_close($conn);
?>
