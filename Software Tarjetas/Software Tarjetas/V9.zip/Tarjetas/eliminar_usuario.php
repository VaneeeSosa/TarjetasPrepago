<?php

require_once('Conexion.php');

$con = new Conexion();
$getConnection = $con->Conectar();

// Verificar si se proporciona un ID de usuario para eliminar
if(isset($_GET['CURP'])) {
    // Obtener la CURP del usuario de la URL
    $usuario_curp = $_GET['CURP'];
     
    try {
        // Preparar la consulta SQL para eliminar el usuario
        $consulta = "DELETE FROM Usuarios WHERE Curp = :curp";

        // Preparar y ejecutar la consulta
        $stmt = $getConnection->prepare($consulta);
        $stmt->bindParam(':curp', $usuario_curp, PDO::PARAM_STR);
        $stmt->execute();

        // Después de ejecutar la consulta, redirigir al usuario a la página principal u otra página
        header("Location: Usuarios.php");
        exit();
    } catch (PDOException $e) {
        // Manejar cualquier error de la base de datos
        echo "Error al eliminar el usuario: " . $e->getMessage();
         header("Location: Error.php");
        exit();
    }
} else {
    // Si no se proporciona una CURP de usuario, redirigir al usuario a alguna otra página
    echo "<script>alert('Error al obtener la CURP del usuario');</script>";
    header("Location: Usuario.php");
    exit();
}
?>
