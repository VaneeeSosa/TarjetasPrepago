<?php
if (isset($_POST['ruta'])) {
    $ruta = $_POST['ruta'];

    // Validar y guardar la ruta
    if (is_dir($ruta)) {
        file_put_contents('ruta.txt', $ruta);
        echo "Ruta guardada: " . $ruta;
    } else {
        echo "La ruta especificada no es válida.";
    }
} else {
    echo "No se ha proporcionado ninguna ruta.";
}
?>

